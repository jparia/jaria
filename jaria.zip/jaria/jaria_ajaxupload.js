﻿	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library 'Jaria' is not loaded!");
	}
	
	
	/* Le transfert de fichier par Ajax */
	
	oAjax.upload = new Upload();
	
	function Upload(){										/* calendrier mensuel avec selecteurs mois & année */
	
		var _this = this;
		
		
		this.id = "";		
		this.form = undefined;
		this.iframe = undefined;
		this.data = undefined;
		this.url = "";
		this.xml = false;
		this.timer = null;
		
		
		this.createIframe = function(){
			if( oEl.isobject(_this.iframe) ){
				oNav.body.removeChild(_this.iframe);
			}
			_this.iframe = oEl.create("iframe");
			_this.iframe.style.display = "none";
			_this.iframe.id = "jaria_iframe_ajaxupload";
			oNav.body.appendChild(_this.iframe);
		};

		this.createForm = function(){
			_this.form = oEl.create("form");
			_this.form.method = "POST";
			_this.form.enctype = "multipart/form-data";
			_this.form.action = _this.url;
			
			var input = oEl.get(_this.id);
			var newinput = input.cloneNode(false);
 			var p = input.parentNode;
			p.insertBefore(newinput, input);
			_this.form.appendChild(input);
			
			if(oEl.isobject(_this.data)){
				for(var d in data){
					var el = oEl.create("input");
					el.type = "hidden";
					el.name =  d;
					el.value = data[d];
					_this.form.appendChild(el);
				}			
			}
			var doc = (_this.iframe.contentDocument) ? _this.iframe.contentDocument : _this.iframe.contentWindow.document; 
			if(oNav.msie){
				var b = oEl.create("BODY");
				b.appendChild(_this.form);
				doc.appendChild(b);
			}
			else{
				doc.body.appendChild(_this.form);	
			}			
			_this.form.submit();
			
			
			
			
		};
		
		
		this.clear = function(){
			try{					
				oNav.body.removeChild(_this.iframe);
				oNav.body.removeChild(_this.form);
				window.clearTimeout(_this.timer);
			}
			catch(e){}
			oEl.get(_this.id).value = "";
			_this.id = "";		
			_this.form = undefined;
			_this.iframe = undefined;
			_this.data = undefined;
			_this.url = "";
			_this.xml = false;
			_this.timer = null;
		};
		
		this.result = function(){
			window.clearTimeout(_this.timer);
			if( _this.iframe == undefined ){
				return false;	
			}	
			var xml = {};
			var doc = _this.iframe.contentWindow.document;
			if(_this.iframe.contentWindow.location.href.lastIndexOf(_this.url) != -1){
				xml.responseText = (doc.body) ? doc.body.innerHTML : null;
				xml.responseXML = (doc.XMLDocument) ? doc.XMLDocument : doc;
				var data = (_this.xml) ? xml.responseXML : xml.responseText;
				_this.action(data);
				oNav.lock.hide();
				_this.clear();
			}
			else{
				_this.timer = window.setTimeout(_this.result, 1000);
			}		
		};
		
		this.action = function(){
			
		};
		
		this.load = function(){

			if(!oEl.test(_this.id) || _this.url == ""){
				return false;
			}
			oNav.lock.texte = "Tranfert du fichier en cours...";
			oNav.lock.image = 6;
			oNav.lock.show();
			_this.createIframe();
			_this.createForm();
			/*_this.frame.onload = function(){
				alert(doc.body.innerHTML);
			};*/
			_this.timer = window.setTimeout(_this.result, 100);		
		};	
		
	
	}
	