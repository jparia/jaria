	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* La visonneuse d'image */
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oViewimg = new Viewimg();						/* Objet Zoom sur image */
	
	function Viewimg(){							/* Zoom sur image */
	
		var _this = this;
		
		_this.identity = this;
		_this.el = undefined;						/* objet image à visionner */
		_this.view = undefined;						/* objet conteneur du viewer */
		_this.img = undefined;						/* objet image du viewer */
		_this.wait = undefined;						/* objet texte d'attente de chargement de l'image du viewer */
		_this.bt = undefined;						/* objet bouton close */
		_this.width = 0;								/* largeur de l'image reelle */
		_this.height = 0;							/* hauteur de l'image reelle */
		_this.timer = null;							/* timer du viewer */
		_this.padding = 0;							/* padding attribué par CSS au viewer */
		_this.isfinaly = false;						/* vieweur finalisé */
		_this.path = "";								/* chemin réélle des images si les soruces sont des vignettes */
				
		_this.inscreen = function(){
			if ( oEl.isobject(_this.view) ){
				oEl.setinscreen(_this.view);
				_this.posclose();
			}
		};

		_this.posclose = function(){					/* position du bouton close */
			if ( oEl.isobject(_this.bt) && oEl.isobject(_this.view) ){
				_this.bt.style.left = oText.toPx( parseInt(parseFloat(_this.view.style.left) + parseFloat(_this.view.style.width) - (_this.padding / 2)) );
				_this.bt.style.top = oText.toPx( parseInt(parseFloat(_this.view.style.top) + _this.padding) );
			}
		};
		
		_this.finaly = function(){					/* Actions finales après agrandissement terminé de la visionneuse */			
			if( oEl.isobject(_this.bt) ){
				return false;
			}
			_this.isfinaly = true;
			oEl.isinscreen = function(){			/* en fin de repositionnement de la visionneuse dans la fenêtre du navigateur */
				if( !oEl.isobject(_this.bt) ){
					_this.bt = oEl.create("div");
					_this.bt.className = "jaria_viewer_close";
					var img = oEl.create("img");
					
					img.src = jaria.images + "box/btclose.png";
					img.alt = "";
					img.title = "Fermer la visionneuse [esc]";
					img.style.cursor = "pointer";
					img.onmouseover = function(){
						this.src = jaria.images + "box/btclose_hover.png";
					};
					img.onmouseout = function(){
						this.src = jaria.images + "box/btclose.png";
					};
					img.onclick = function(){
						_this.hide();
					};
					_this.bt.appendChild(img);
					oNav.body.appendChild(_this.bt);
					var f = (oNav.msie) ? 10 : 40;
					oEl.fader.plus(_this.bt, f);					
				}
				_this.posclose();
			};
			/* repositionne la visionneuse dans la fenêtre du navigateur */
			_this.inscreen();			
		};
		
		_this.enlarge = function(){
			if( _this.el == undefined ){				
				return false;
			}
			var inc = 40;
			var rapp = ( _this.width > _this.height ) ? parseFloat(_this.height) / parseFloat(_this.width) : parseFloat(_this.width) / parseFloat(_this.height) ;
			var incW = ( _this.width > _this.height ) ? parseFloat(inc) / parseFloat(rapp) : parseFloat(inc);
			var incH = ( _this.height > _this.width ) ? parseFloat(inc) / parseFloat(rapp) : parseFloat(inc);
			if( !_this.isfinaly ){
				/* dimensions réelles atteintes ou supérieures à la fenêtre */
				if( 
				   ( parseFloat(_this.view.style.width) >= _this.width && parseFloat(_this.view.style.height) >= _this.height ) ||
				   ( parseFloat(_this.view.style.width) >= oNav.screenX - 100 ) || 
				   ( parseFloat(_this.view.style.height) >= oNav.screenY - 100 )																						   
				){
					oNav.init_timer(_this.timer);
					_this.timer = null;				
					_this.finaly();
					return false;
				}
				/* agrandie l'image jusqu'aux dimensions passées en paramètre */
				if( parseFloat(_this.img.style.width) < _this.width ){
					_this.view.style.width = oText.toPx(parseInt(parseFloat(_this.view.style.width) + incW));
					_this.img.style.width = oText.toPx(parseInt(parseFloat(_this.img.style.width) + incW));
				}
				if( parseFloat(_this.img.style.height) < _this.height ){
					_this.view.style.height = oText.toPx(parseInt(parseFloat(_this.view.style.height) + incH));
					_this.img.style.height = oText.toPx(parseInt(parseFloat(_this.img.style.height) + incH));
				}
				/* centre l'image sur sa référence */
				if( parseFloat(_this.view.style.left) > oNav.scrollX ){
					_this.view.style.left = oText.toPx( parseInt(oEl.getoffset(_this.el, "offsetLeft") + (oEl.getoffset(_this.el, "offsetWidth") / 2) - (parseFloat(_this.view.style.width) / 2)) );
				}
				if( parseFloat(_this.view.style.top) > oNav.scrollY ){
					_this.view.style.top = oText.toPx( parseInt(oEl.getoffset(_this.el, "offsetTop") + (oEl.getoffset(_this.el, "offsetHeight") / 2) - (parseFloat(_this.view.style.height) / 2)) );
				}
				_this.timer = window.setTimeout(_this.enlarge, 10);
			}
		};
		
		
		_this.waitloaded = function(){
			if( !oEl.isobject(_this.img) ){
				return false;
			}
			if( !_this.img.complete ){
				/* image pas encore chargée, on attend... */
				_this.timer = window.setTimeout(_this.waitloaded, 100);
				return false;
			}
			
			oNav.init_timer(_this.timer);

			/* récupère les dimensions réélles de l'image */
			if( _this.width == 0 ){
				_this.width = oEl.getoffset(_this.img, "offsetWidth");
			}
			if( _this.height == 0 ){
				_this.height = oEl.getoffset(_this.img, "offsetHeight");
			}
			
			/* attribut les styles css à l'image chargée */
			_this.img.style.width = oText.toPx(oEl.getoffset(_this.el, "offsetWidth"));
			_this.img.style.height = oText.toPx(oEl.getoffset(_this.el, "offsetHeight"));
			try{
				_this.view.removeChild(_this.wait);
			}
			catch(e){}
			_this.img.style.visibility = "visible";
			/* affichage progressif du viewer */
			var f = (oNav.msie) ? 10 : 40;
			oEl.fader.plus(_this.view, f);
			
			/* débute l'élargissement du viewer */
			_this.enlarge();
			
		};
		
		_this.show = function(event){				/* affiche le zoom d'un partie l'image destination */
		
			/* 
				argument 0: event ou object obligatoire
				argument 1: largeur reélle de l'image	facultatif
				argument 2: hauteur reèlle de l'image	facultatif
			
			*/			
			if( !oNav.ready ){
				return false;
			}
			
			oNav.init_timer(_this.timer);
			
			var el = undefined;
			
			if( arguments.length > 0 ){
				if(oEl.isobject(arguments[0])){
					el = oEl.getevent(arguments[0]);
				}
			}
			else{
				if(oEl.isobject(this)){
					el = this;
				}
			}
			
			if(el == undefined){
				return false;
			}
			if (el.tagName.toLowerCase() != "img"){
				return false;
			}
			
			_this.el = el;			
			
			if( arguments.length >= 3 ){
				if( !isNaN(arguments[1]) && !isNaN(arguments[2]) ){
					_this.width = parseInt(arguments[1]);
					_this.height = parseInt(arguments[2]);
				}				
			}
			
			/* Création du viewer  */
			if( !oEl.isobject(_this.view) ){
				oNav.lock.opacity = 80;
				oNav.lock.color = "#6E6F6F";
				oNav.lock.anim = false;
				oNav.lock.show();
				
				/* conteneur principale du viewer */
				_this.view = oEl.create("div");
				_this.view.className = "jaria_viewer";
				var prop = "offsetWidth";
				_this.view.style.width = oText.toPx(oEl.getoffset(_this.el, "offsetWidth"));
				_this.view.style.height = oText.toPx(oEl.getoffset(_this.el, "offsetHeight"));
				_this.view.style.top = oText.toPx(oEl.getoffset(_this.el, "offsetTop") - 20);
				_this.view.style.left = oText.toPx(oEl.getoffset(_this.el, "offsetLeft") - 20);
				
				/* image de viewer */
				_this.img = oEl.create("img");			
				_this.img.src = ( _this.path != "" ) ? _this.path + oText.filefullname(el.src) : el.src;
				_this.img.style.visibility = "hidden";
				_this.img.className = "jaria_viewer_img";
				_this.img.title = "Fermer la visionneuse";
				_this.img.onclick = _this.hide;
				_this.wait = oEl.text("Chargement de l'image en cours...");
								
				/* ajout de l'image et du viewer dans le DOM */
				_this.view.appendChild(_this.wait);
				_this.view.appendChild(_this.img);
				oNav.body.appendChild(_this.view);
				
				/* marge définie dans le CSS */
				_this.padding = parseFloat(oEl.getstyleclass(_this.view, "paddingLeft"));
				
				/* attend le chargement complet de l'image pour continuer */
				_this.waitloaded();
		
			}
		};		
		
		_this.hide = function(){						/* détruit le zoom et le viewer */		
			/* redéfini la fonction d'action de finde fading */
			try{
				oNav.body.removeChild(_this.bt);
			}
			catch(e){}
			oEl.fader.valid = function(){
				oNav.init_timer(_this.timer);
				try{
					oNav.body.removeChild(_this.view);					
				}
				catch(e){}
				oNav.lock.hide();
				_this.el = undefined;
				_this.view = undefined;
				_this.img = undefined;
				_this.bt = undefined;
				_this.width = 0;
				_this.height = 0;
				_this.timer = null;
				_this.isfinaly = false;
				oEl.fader.valid = function(){
					return false;
				};
			};
			var f = (oNav.msie) ? 10 : 40;
			oEl.fader.moins(_this.view, f);
		};
		
		/* redéfini la fonction oNav.hideallbox pour prendre en compte la visionneuse d'image dans l'évènement de la touche ESCAPE */
		var hideallbox = new oNav.hideallbox();	
		oNav.hideallbox = function(){
			hideallbox;
			_this.hide();
		};
		
		/* ajoute la fonction de repositionnement du bouton close lié au srcolling de la page */
		oNav.addevent("onresize", _this.posclose);
		oNav.addevent("onscroll", _this.inscreen);		
		
	}
	
	