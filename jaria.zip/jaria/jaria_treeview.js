	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
		
	/* Le tree view */
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	oEl.treeview = new Treeview();
	
	function Treeview(){
		
		var _this = this;
		
		this.el = undefined;			/* élement treeview */ 
		this.pathXml = "";				/* chemin du fichier xml des données */
		this.width = 200;				/* largeur du treeview sans scrolling */
		this.wait = 5;					/* délai d'attente en seconde du chargement du XML avant alerte */
		this.xml = undefined;			/* xml chargé */
		this.created = false;
		this.timer = null;
		this.index = 0;
		
		this.LoadXml = function(){		/* chargement du fihier XML dont le chemin est affecté à Treeview.pathXml */
			oNav.lock.show();
			oAjax.init();
			oAjax.timeout = (this.wait * 1000);			
			oAjax.send(this.pathXml, "get");
			oAjax.ontimeout = function(){
				oBox.alert("Impossible de charger le document XML " +  oText.filefullname(this.pathXml) + "!");
			};
			oAjax.recept = function(){
				_this.xml = arguments[0];
				_this.create();
			};			
			oAjax.onready("xml");
		};
		
		this.create = function(){			
			this.el.style.width = oText.toPx(this.width);
			this.el.style.overflow = "auto";
			var dirs = oEl.gettags("DOSSIER", this.xml);
			var cdir, cfile, dir, files, file;			
			for (var i = 0; i < dirs.length; i++){				
				dir = oEl.create("div");
				dir.className = "jaria_treeview_dir";
				dir.innerHTML = dirs[i].getAttribute("nom");		
				dir.onclick = this.display;
				dir.onmouseover = function(){
					this.className = "jaria_treeview_dir_hover";
				};
				dir.onmouseout = function(){
					this.className = "jaria_treeview_dir";
				};
				files = oEl.gettags("FICHIER", dirs[i]);
				cfile = oEl.create("div");
				cfile.style.display = "none";
				for (var y = 0; y < files.length; y++){	
					file = oEl.create("div");
					file.className = "jaria_treeview_doc";
					file.innerHTML = files[y].firstChild.nodeValue;
					file.setAttribute("dataset.action", files[y].getAttribute("action"));
					file.onclick = function(){
						_this.action(this.getAttribute("dataset.action"));
					};
					cfile.appendChild(file);
				}
				cdir = oEl.create("div");
				cdir.appendChild(dir);
				cdir.appendChild(cfile);
				this.el.appendChild(cdir);
			}
			this.created = true;
			this.loaded();
			oNav.lock.hide();
		};
		
		this.show = function(id){		/* chargement du treeview */
			if(!oEl.test(id)){
				oBox.alert("l'élément " + id + " n'est pas trouvé!");
				return false;
			}
			this.el = oEl.get(id);
			this.el.className = "jaria_treeview_el";			
			this.LoadXml();		
		};
		
		this.open = function(){		/* affiche le contenu d'un dossier selon l'index passé commençant à 0 */
			if( this.created  == false ){
				if( arguments.length > 0){
					this.index = (isNaN(arguments[0])) ? 0 : parseInt(arguments[0]);
				}
				this.timer = window.setTimeout(_this.open, 100);
				return false;
			}
			window.clearTimeout(this.timer);
			var dirs = oEl.getclass("jaria_treeview_dir", this.el);
			var dir = undefined;
			for (var i = 0; i < dirs.length; i++){
				if( i == this.index ){
					dir = dirs[i];
				}
			}
			if( dir != undefined ){
				var n = dir.parentNode.childNodes;
				for (var i = 0; i < n.length; i++){
					if (n[i].nodeType == 1 && n[i].style.display != ""){
						n[i].style.display = "block";
						break;
					}
				}	
			}
		};
		
		this.display = function(){			/* affiche le contenu d'un dossier sur l'évènement onclick de celui-ci */	
			var n = this.parentNode.childNodes;
			for (var i = 0; i < n.length; i++){
				if (n[i].nodeType == 1 && n[i].style.display != ""){
					n[i].style.display = ( n[i].style.display == "none" ) ? "block" : "none";
					break;
				}
			}
		};
		
		this.action = function(){		/* fonction a redéfinir selon l'action désirée en utilisant le paramètre action défini dans chaque balise DOCUMENT du fichier XML */
			var action = arguments[0];
			return false;
		};

		this.load = function(){
			oNav.loadimg(
				jaria.images + "treeview/dir.png",
				jaria.images + "treeview/doc.png"
			);			
		};
		
		this.loaded = function(){		/* fonction a redéfinir pour éventuellement effectuer une action après chargement du treeview */
			return false;
		};
		
	}
	
	oNav.addevent("onload", function(){
		oEl.treeview.load();
	});
