	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/	
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	oEl.editor = new Editor();
	
	/* L'éditeur de texte */
	
	function Editor(){
		var _this = this;
		this.el = undefined;
		this.iframe = undefined;
		this.inputcolor = undefined;
		this.btcolor = undefined;
		this.bt = [];
		this.width = 600;										/* Largeur de l'éditeur */
		this.height = 250;									/* Hauteur de l'éditeur */
		this.html = false;									/* Les balise au format HTML au lieu de BBCODE */
		this.bt_h1 = true;									/* affiche le bouton H1 */
		this.bt_h2 = true;									/* affiche le bouton H2 */
		this.bt_h3 = true;									/* affiche le bouton H3 */
		this.bt_h4 = true;									/* affiche le bouton H4 */
		this.bt_color = true;								/* affiche le bouton de la palette des couleurs */
		this.bt_emoticone = true;						/* affiche le bouton des émoticones */
		
		this.emoticons = new Emoticones();
		
		function Emoticones(){
			
			this.el = undefined;
			
			this.drag = function(event){
				oEl.drag.opacity = 65;
				oEl.drag.start(_this.emoticons.el, event);
			};
			
			this.show = function(){
				oNav.hideallbox();
				oNav.lock.anim = false;
				oNav.lock.show();
				oText.select(false);
				this.el = oEl.create("div");
				this.el.className = "jaria_cal_box";
				this.el.style.zIndex = 100;
				this.el.style.width = "145px";
				div = oEl.create("div");
				div.className = "jaria_cal_head";
				div.onmousedown = this.drag;
				div.title = "clic droit ou [esc] pour quitter";
				div.oncontextmenu = this.hide;
				this.el.appendChild(div);
				div = oEl.create("div");
				div.style.paddingTop = "2px";
				tb = oEl.create("table");
				tb.className = "jaria_cal_tb";
				tb.cellspacing = 2;
				tbo = oEl.create("tbody");
				var t = [];
				t[0] = new Array("smile", "biggrin", "wink", "love", "sol"); 
				t[1] = new Array("pfff", "frown", "mdr", "non", "sweat");  
				t[2] = new Array("cry", "ouch", "redface", "pt1c", "heink");
				var id = [];
				id[0] = new Array(":)", ":D", ";)", ":love:", ":sol:"); 
				id[1] = new Array(":pff:", ":(", ":-D", ":non:", ":sweat:");  
				id[2] = new Array(":cry:", ":ouch:", ":o", ":pt1c:", ":heink:");
				for( var i = 0; i < t.length; i++){
					tr = oEl.create("tr");
					for( var y =0; y < t[i].length; y ++){
						td = oEl.create("td");
						td.className = "jaria_emoticon_" + t[i][y];
						td.id = id[i][y];
						td.innerHTML = "&nbsp;";
						td.onclick = function(){
							_this.addtext(null, this.id);
							_this.emoticons.hide();
						};
						tr.appendChild(td);
					}
					tbo.appendChild(tr);
				}
				tb.appendChild(tbo);
				div.appendChild(tb);
				this.el.appendChild(div);				
				oNav.body.appendChild(this.el);	
				oNav.contextmenu(false, this.el);
				this.el.style.left = oText.toPx(oNav.mouse.X + oNav.scrollX);
				this.el.style.top = oText.toPx(oNav.mouse.Y + oNav.scrollY);				
				oEl.setinscreen(this.el);
			};
			
			this.hide = function(){
				var em = _this.emoticons;
				var el = em.el;
				if( el == undefined ){
					return false;
				}
				try{
					oNav.body.removeChild(el);
				}
				catch(e){}
				el = undefined;
				oNav.lock.hide();
				oText.select(true);
				oNav.contextmenu(true);
			};
			
		}
		
		this.panelcolor = function(){
			var p, panel, sdiv;
			p = this.el.parentNode;
			panel = oEl.create("div");	
			panel.style.display = "none";
			this.inputcolor = oEl.create("input");
			this.inputcolor.value = "";
			this.inputcolor.className = "jaria_color";			
			this.btcolor = oEl.create("div");
			this.btcolor.className = "jaria_btcolor";			
			sdiv = oEl.create("this.btcolor");
			sdiv.className = "jaria_btscolor";
			this.btcolor.appendChild(sdiv);
			sdiv = oEl.create("this.btcolor");
			sdiv.className = "jaria_btsscolor";
			this.btcolor.appendChild(sdiv);
			panel.appendChild(this.inputcolor);
			panel.appendChild(this.btcolor);
			p.appendChild(panel);
			return panel;
		};
		
		this.cleantext = function(t){
			if( oText.test(t) ){
				if( _this.html ){
					t = t.replace(/\r\n/g, "<br />");
					t = t.replace(/\n/g, "<br />");				
				}else{
					t = t.replace(/\r\n/g, "[br]");
					t = t.replace(/\n/g, "[br]");
					t = t.replace(/\t/g, "");
					t = t.replace(/'/g, "\'");
					t = t.replace(/&/g, "");
					t = t.replace(/</g, "");
					t = t.replace(/>/g, "");
				}
			}
			return t;
		};
		
		this.encode = function(t){
			if( oText.test(t) ){
				t = this.cleantext(t);
				if( !_this.html ){
					t = t.replace(/\[br\]/g, "<br />");
					t = t.replace(/\n/g, "<br />");
					t = t.replace(/\[b\]/g, "<b>");
					t = t.replace(/\[i\]/g, "<i>");
					t = t.replace(/\[u\]/g, "<u>");
					t = t.replace(/\[s\]/g, "<s>");
					t = t.replace(/\[\/b\]/g, "</b>");
					t = t.replace(/\[\/i\]/g, "</i>");
					t = t.replace(/\[\/u\]/g, "</u>");
					t = t.replace(/\[\/s\]/g, "</s>");
					if( _this.bt_h1 ){
						t = t.replace(/\[h1\]/g, "<h1>");
						t = t.replace(/\[\/h1\]/g, "</h1>");
					}
					if( _this.bt_h2 ){
						t = t.replace(/\[h2\]/g, "<h2>");
						t = t.replace(/\[\/h2\]/g, "</h2>");
					}
					if( _this.bt_h3 ){
						t = t.replace(/\[h3\]/g, "<h3>");
						t = t.replace(/\[\/h3\]/g, "</h3>");
					
					}
					if( _this.bt_h4 ){
						t = t.replace(/\[h4\]/g, "<h4>");
						t = t.replace(/\[\/h4\]/g, "</h4>");
					}
					if( _this.bt_color ){
						t = t.replace(/\[color=/g, "<span style='color:");				
						t = t.replace(/\[\/color\]/g, "</span>");
						t = t.replace(/\]/g, "'>");
					}
				}
				if( _this.bt_emoticone ){
					t = t.replace(/:\)/g, "<img src='" + jaria.images + "editor/emoticons/smile.gif' />");
					t = t.replace(/:D/g, "<img src='" + jaria.images + "editor/emoticons/biggrin.gif' />");
					t = t.replace(/;\)/g, "<img src='" + jaria.images + "editor/emoticons/wink.gif' />");
					t = t.replace(/:love:/g, "<img src='" + jaria.images + "editor/emoticons/love.gif' />");
					t = t.replace(/:sol:/g, "<img src='" + jaria.images + "editor/emoticons/sol.gif' />");				
					t = t.replace(/:\(/g, "<img src='" + jaria.images + "editor/emoticons/frown.gif' />");
					t = t.replace(/:-D/g, "<img src='" + jaria.images + "editor/emoticons/mdr.gif' />");
					t = t.replace(/:non:/g, "<img src='" + jaria.images + "editor/emoticons/non.gif' />");
					t = t.replace(/:sweat:/g, "<img src='" + jaria.images + "editor/emoticons/sweat.gif' />");
					t = t.replace(/:cry:/g, "<img src='" + jaria.images + "editor/emoticons/cry.gif' />");
					t = t.replace(/:ouch:/g, "<img src='" + jaria.images + "editor/emoticons/ouch.gif' />");
					t = t.replace(/:o/g, "<img src='" + jaria.images + "editor/emoticons/redface.gif' />");
					t = t.replace(/:pt1c:/g, "<img src='" + jaria.images + "editor/emoticons/pt1c.gif' />");
					t = t.replace(/:heink:/g, "<img src='" + jaria.images + "editor/emoticons/heink.gif' />");
					t = t.replace(/:pff:/g, "<img src='" + jaria.images + "editor/emoticons/pfff.gif' />");
				}
			}				
			return t;		
		};

		this.addbutton = function(t, l, f){
			this.bt[t] = oEl.create("button");
			this.bt[t].className = "jaria_editor_" + t;
			this.bt[t].title = l;
			this.bt[t].setAttribute("data-value", t);
			switch (t){
				case "c":
					this.bt[t].onclick = function(){
						oColor.picker.valid = function(){
							var v = _this.inputcolor.value;
							if( oColor.iscolor(v) ){
								if( _this.html ){
									_this.addtext(null, "font style=\"color:" + oText.lower(v) + "\"");
								}
								else{
									_this.addtext(null, "color=" + v);
								}
							}
						};
						oColor.picker.show(_this.btcolor);
					};				
					break;
				case "e":
					this.bt[t].onclick = function(){
						_this.emoticons.show();
						return false;
					};
					break;
				default:
					this.bt[t].onclick = f;
			}
			return this.bt[t];
		};
		
		this.init = function(id){
			if( !oEl.test(id) ){
				return false;
			}
			_this.el = oEl.get(id);
			var p = this.el.parentNode;
			p.removeChild(_this.el);
			p.appendChild(_this.addbutton("b", "gras", _this.addtext));
			p.appendChild(_this.addbutton("i", "italic", _this.addtext));
			p.appendChild(_this.addbutton("u", "souligné", _this.addtext));
			p.appendChild(_this.addbutton("s", "barré", _this.addtext));
			if(_this.bt_h1){
				p.appendChild(_this.addbutton("h1", "H1", _this.addtext));
			}
			if(_this.bt_h2){
				p.appendChild(_this.addbutton("h2", "H2", _this.addtext));
			}
			if(_this.bt_h3){
				p.appendChild(_this.addbutton("h3", "H3", _this.addtext));
			}			
			if(_this.bt_h4){
				p.appendChild(_this.addbutton("h4", "H4", _this.addtext));
			}			
			if(_this.bt_color){
				p.appendChild(_this.addbutton("c", "couleur", null));
			}
			if(_this.bt_emoticone){
				p.appendChild(_this.addbutton("e", "émoticone", null));
			}	
			p.appendChild(_this.addbutton("h", "html", _this.see));			
			var br = oEl.create("br");
			p.appendChild(br);
			_this.iframe = oEl.create("div");
			_this.iframe.className = "jaria_editor_html";
			_this.iframe.style.width = oText.toPx(_this.width);
			_this.iframe.style.height = oText.toPx(_this.height);
			p.appendChild(_this.iframe);
			_this.el.style.width = oText.toPx(_this.width);
			_this.el.style.height = oText.toPx(_this.height);
			_this.el.className = "jaria_textarea";
			p.appendChild(_this.el);
			p.appendChild(_this.panelcolor());
			oColor.picker.input.push(this.input);
			oEl.visible(_this.iframe, false);
			_this.load();
		};
		
		this.addtext = function(){
			var tag = ( arguments.length > 1 ) ? arguments[1] : this.getAttribute("data-value");
			var bd = (_this.html) ? "<" : "[";
			var bf = (_this.html) ? ">" : "]";
			var el = _this.el;
			if( !oEl.isvisible(el) ){
				return false;
			}
			if( tag.substr(0, 1) == ":" ||  tag.substr(0, 1) == ";" ){
				var startag = tag;
				var endtag = "";
			}else{
				var startag = bd + tag + bf;
				var t = tag.split(/=/g);
				var endtag = (t.length > 1) ? bd + "/" + t[0].replace(/ style/g, "") + bf : bd + "/" + tag + bf;
			}
			if ( !oNav.msie || (oNav.msie &&  oNav.version >= 11)){
				var v = el.value;	
				var deb = el.selectionStart;
				var fin = el.selectionEnd;
				var vdeb = v.substring( 0 , el.selectionStart );
				var vfin = v.substring( el.selectionEnd , el.textLength );
				var vsel = v.substring( el.selectionStart ,el.selectionEnd );
				el.value = vdeb + startag + vsel + endtag + vfin;
				el.selectionStart = vdeb.length;
				el.selectionEnd = (vdeb + startag + vsel + endtag).length;
				el.focus();
				el.setSelectionRange(
					vdeb.length + tag.length + 2,
					vdeb.length + tag.length + 2
				);
			}else{
				if ( el.createTextRange ){
					el.focus(el.caretPos);
					el.caretPos = document.selection.createRange().duplicate();
					if ( el.caretPos.text.length > 0 ){
						var sel = el.caretPos.text;
						var fin = "";
						while( sel.substring(sel.length-1, sel.length) == " " ){
							sel = sel.substring(0, sel.length-1);
							fin += " ";
						}
						el.caretPos.text = startag + sel + endtag + fin;
					}
					else{
						el.caretPos.text = startag + " " + endtag;
					}
				}
				else{
					el.value += startag + " " + endtag;
				}
			}
			return false;
		};
		
		this.see = function(){
			if( oEl.isvisible(_this.el) ){
				oEl.visible(_this.el, false);
				oEl.visible(_this.iframe, true);						
				_this.setsee();				
				_this.bt["h"].className = "jaria_editor_t";
				_this.bt["h"].title = "code";
				_this.setsee();
			}else{
				oEl.visible(_this.el, true);
				oEl.visible(_this.iframe, false);					
				_this.bt["h"].className = "jaria_editor_h";
				_this.bt["h"].title = "html";
			}
			return false;
		};

		
		this.setsee = function(){
			_this.iframe.innerHTML =_this.encode(_this.el.value.toString());
		};	
		
		this.load = function(){
			oNav.loadimg(
				jaria.images + "editor/btbold.png",
				jaria.images + "editor/btcode.png",
				jaria.images + "editor/btcolor.png",
				jaria.images + "editor/btemoticon.png",
				jaria.images + "editor/btH1.png",
				jaria.images + "editor/btH2.png",
				jaria.images + "editor/btH3.png",
				jaria.images + "editor/btH4.png",
				jaria.images + "editor/bthtml.png",
				jaria.images + "editor/btitalic.png",
				jaria.images + "editor/btstrike.png",
				jaria.images + "editor/btunderline.png",
				jaria.images + "editor/emoticons/biggrin.gif",
				jaria.images + "editor/emoticons/cry.gif",
				jaria.images + "editor/emoticons/frown.gif",
				jaria.images + "editor/emoticons/heink.gif",
				jaria.images + "editor/emoticons/love.gif",
				jaria.images + "editor/emoticons/mdr.gif",
				jaria.images + "editor/emoticons/non.gif",
				jaria.images + "editor/emoticons/ouch.gif",
				jaria.images + "editor/emoticons/pfff.gif",
				jaria.images + "editor/emoticons/pt1c.gif",
				jaria.images + "editor/emoticons/redface.gif",
				jaria.images + "editor/emoticons/smile.gif",
				jaria.images + "editor/emoticons/sol.gif",
				jaria.images + "editor/emoticons/sweat.gif",
				jaria.images + "editor/emoticons/wink.gif"
			);		
			
		};	

	}

