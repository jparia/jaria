	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	/* Les listes personnlisées*/	

	oEl.list = new List();

	function List(){
		
		var _this = this;
	
		_this.el = undefined;
		_this.backgrounColor = "#fff";									/* mémorise le style CSS de la couleur de fond de la liste pour la restituer en cas de suppression des options */
		
		_this.init = function(){												/* ajoute les évènements onclick, onfocus ainsi que la class sliste aux options des listes */
			/*
				argument 0 : true ou false pour l'ombre facultatif
			*/
			var ombre = ( typeof(arguments[0]) == "boolean" ) ? arguments[0] : true;
	
			/* listes simples */
			
			var fc = [];																	/* tableau des éventuelles fonctions à ajouter sur l'évènement onchange */			
			var sels = oEl.getclass("jaria_listlock");			
			_this.backgrounColor = (sels.length > 0 ) ? oEl.getstyleclass(sels[i], "backgrounColor") : "#fff";
			
			for( var i = 0; i < sels.length; i++ ){				/* ajoute les évènements onclick et onfocus et onchange */
				
				if( typeof(sels[i].onclick) != "function" ){					
					sels[i].onclick = function(){
						_this.get(this, ombre);
					};
				}
				if( typeof(sels[i].onfocus) != "function" ){
					sels[i].onfocus = _this.hide;
				}
				if( typeof(sels[i].onchange) == "function" ){
					fc[i] = sels[i].onchange;
				}
				/* évite le décalage de l'image de fond css si le texte est trop long */
				if( oNav.msie &&  oNav.version < 9 ){								
					var w = sels[i].offsetWidth;
					w -= parseFloat(oEl.getstyleclass(sels[i], "paddingRight"));
					w += parseFloat(oEl.getstyleclass(sels[0], "borderWidth"));
					sels[i].style.backgroundPosition = oText.toPx(w);
				}
			}
			var lists = oEl.getclass("jaria_liste");			/* ajoute la classe et l'évènement onclick à l'option */
			for( var i = 0; i < lists.length; i++ ){
				var opts = oEl.gettags("div", lists[i]);
				for( var y = 0; y < opts.length; y++ ){
					oEl.addclass(opts[y], "jaria_sliste");
					/* compatibilité antérieure */
					if( !oText.test(opts[y].getAttribute("data-value")) && oText.test(opts[y].getAttribute("title")) ){
						opts[y].setAttribute("data-value", opts[y].getAttribute("title"));
						opts[y].removeAttribute("title");
					}
					if( typeof(opts[y].onclick) != "function" ){
						opts[y].onclick = function(){
							_this.set(this);
						}
					}
					oNav.addevent("onclick", fc[i], opts[y]);
					oNav.delevent("onchange", fc[i], sels[i]);
				}
			}
			
			/* listes multiples */
			var divs = oEl.getclass("jaria_mliste");
			for( var i = 0; i < divs.length; i++ ){		/* ajoute l' évènement onclick */
				if( oNav.msie ){
					divs[i].style.scrollbarFaceColor = "#bcccf3";
					divs[i].style.scrollbarShadowColor = "#afc5f4";
					divs[i].style.scrollbarHighlightColor = "#e6eefc";
					divs[i].style.scrollbar3dlightColor = "#afc5f4";
					divs[i].style.scrollbarDarkshadowColor = "#fff";
					divs[i].style.scrollbarTrackColor = "#fff";
					divs[i].style.scrollbarArrowColor = "#4d6185";
				}
				var opts = oEl.gettags("div", divs[i]);
				for( var y = 0; y < opts.length; y++ ){
					oEl.addclass(opts[y], "jaria_smliste");
					/* compatibilité antérieure */
					if( !oText.test(opts[y].getAttribute("data-value")) && oText.test(opts[y].getAttribute("title")) ){
						opts[y].setAttribute("data-value", opts[y].getAttribute("title"));
						opts[y].removeAttribute("title");
					}
					if( typeof(opts[y].onclick) != "function" ){
						opts[y].onclick = function(){
							_this.setm(this);
						};
					}
				}
			}
		};		

		_this.hide = function(){							/* ferme les liste déroulantes ouvertes ainsi que l'ombre associée */			
			var opts = oEl.getclass("jaria_liste");			
			for( var i = 0 ; i < opts.length; i++ ){
				oEl.visible(opts[i], false);
			}			
			var ombre = oEl.getclass("jaria_ombre");
			for( var i = 0 ; i < ombre.length; i++ ){						
				ombre[i].parentNode.removeChild(ombre[i]);
			}
			var ombre = oEl.getclass("jaria_ombre");
		};
		
		_this.mouseover = function(event){				/* souris sur un élément de la liste [options] */
			var el = oEl.getevent(event);
			var nodes = el.parentNode.childNodes;
			for( var i = 0; i < nodes.length; i++ ){
				if( nodes[i].nodeType == 1 ){
					if (nodes[i].className == "jaria_slisteover"){
						nodes[i].className = "jaria_sliste";
					}
				}
			}
			if (el.className == "jaria_sliste"){
				el.className = "jaria_slisteover";
			}			
		};
		
		_this.mouseout = function(event){				/* souris en dehors d'un élément de la liste [options] */
			var el = oEl.getevent(event);
			if (el.className == "jaria_slisteover"){
				el.className = "jaria_sliste";
			}		
		};
		
		_this.get = function(){						/* Affiche la liste [options] */
			/*
				argument 0 : obligatoire		élément node
				argument 1 : facultatif			évènement traité
				arguments 1 ou 2: facultatif	boolean	pour l'ombre (true par défaut)
			*/			
			if( arguments.length == 0 ){
				return false	
			}
			var node = arguments[0];
			var ombre = true;
			if( !oEl.isobject(arguments[1]) && typeof(arguments[1]) == "boolean" ){
				ombre = arguments[1];
			}
			var e = ( oEl.isobject(arguments[1]) ) ? arguments[1] : undefined;
			var div = oEl.getclass("jaria_liste", node.parentNode)[0];
			if( _this.getcountoptions(div) == 0){
				return false;
			}
			div.style.zIndex = 1000;
			var sel = oEl.getclass("jaria_listlock", node.parentNode)[0];	
			var opts = div.childNodes;
			div.style.width = oText.toPx(parseFloat(sel.style.width) + 21);
			var dX = (oNav.msie && parseFloat(oNav.version) < 8) ? 11 : 0;
			var dY = (oNav.msie && parseFloat(oNav.version) < 8) ? 17 : 1;
			//div.style.left = oText.toPx(oEl.getoffset(sel, "offsetLeft") + dX);
			//div.style.top = oText.toPx(oEl.getoffset(sel, "offsetTop") + oEl.getoffset(sel, "offsetHeight") + dY);
			_this.el = sel;
			if( !oEl.isobject(e) ){
				_this.hide();
				if( oEl.isvisible(div) ){
					return false;
				}
			}
			var z = 0;
			var y = 0;
			for( var i = 0; i < opts.length; i++ ){				/* sélectionne la valeur dans la liste */
				if( opts[i].nodeType == 1 ){			
					var h = oEl.getoffset(opts[i], "offsetHeight");	
					opts[i].className = "jaria_sliste";
					if( opts[i].innerHTML == sel.value ){						
						opts[i].className = "jaria_slisteover";
						opts[i].parentNode.scrollTop = z * h ;
						y = i;
					}
					z++;
				}
			}
			if( oEl.isobject(e) && oEl.isvisible(div) ){		/* sélectionne le node suivant ou précédent selon l'évènement clavier */
				try{
					if( e.keyCode == 40 ){
						y++;
						while( opts[y].nodeType != 1 && y < opts.length ){
						 y++;
						}
					}else{
						y--;
						while( opts[y].nodeType != 1 && y >= 0 ){
							y--;
						}									
					}
					for( var i = 0; i < opts.length; i++ ){
						if( opts[i].nodeType == 1 ){
							opts[i].className = "jaria_sliste";
						}
					}
					opts[y].className = "jaria_slisteover";
					i = y;
					var value = (_this.getoptionvalue(opts[i])).toString().replace(/"/g, "");
					_this.set( opts[y], value, e );
					opts[y].parentNode.scrollTop = y * 3;
				}catch(E){}		
				return false;				
			}
			else{
				oNav.addevent("onmouseover", _this.mouseover);
				oNav.addevent("onmouseout", _this.mouseout);				
				_this.resize(div);
				if( ombre ){
					_this.ombre(div);
				}
			}
		};
		
		_this.set = function(){				/* retourne l'otpion sélectionnée */
			/*
				argument 0 : obligatoire		élément option
				argument 2 : facultatif			évènement clavier
			*/
			if( arguments.length == 0 ){
				return false;
			}
			var opt = arguments[0];
			var v = opt.getAttribute("data-value");
			var e = (arguments.length == 3 ) ? arguments[2] : undefined;
			var p = opt.parentNode.parentNode;
			var i =  oEl.getclass("jaria_listlock", p)[0];
			i.value = opt.innerHTML;
			i.style.backgroundColor = opt.style.backgroundColor;
			i.style.color = opt.style.color;
			var t = oEl.gettags("input", p);
			var h = undefined;
			for( x in t ){				
				if(t[x].type == "hidden" && h == undefined){
					h = t[x];
					break;
				}
			}
			h.value = ( oText.test(v) ) ? v.toString().replace(/"/g, "") : "";
			if( e == undefined ){
				_this.hide();
			}
		};
		
		_this.getcountoptions = function(p){				/* retourne le nombre d'options de la liste */
			var nb = 0;
			for( var i = 0; i < p.childNodes.length; i++ ){
				if( p.childNodes[i].nodeType == 1 ){
					nb++;
				}
			}
			return nb;
		};
		
		_this.getheightoptions = function(p, h){				/* retourne le nombre d'options de la liste */
			
			var r = 0;
			var opts = oEl.gettags("div", p);
			for( var i = 0; i < opts.length; i++ ){
				r += oEl.getoffset(opts[i], "offsetHeight");
				if(!isNaN(h) &&  r > parseFloat(h)){
					break;
				}
			}
			return r;
		};
		
		_this.getindex = function(id){				/* retourne l'index à partir de 0 de l'élément de la liste sélectionné [options]  */
			var p = oEl.get(id).parentNode;
			var y = 0;
			var input = oEl.getclass("jaria_listlock", p)[0];
			//var value = ( oNav.msie ) ? parent.childNodes[0].value : parent.childNodes[1].value;
			var div = oEl.getclass("jaria_liste", p)[0];
			var nodes = div.childNodes;
			for( var i = 0; i < nodes.length; i++ ){
				if( nodes[i].nodeType == 1 ){
					if( nodes[i].innerHTML == value ){
						return y;
					}
					y++;
				}
			}
			return 0;			
		};
		
		_this.getoptions = function(id){
			var p = oEl.get(id).parentNode;
			var c = oEl.getclass("jaria_liste", p);
			return c[0].getElementsByTagName("*");					
		};
		
		_this.setindex = function(id, index){		/* sélectionne la liste par l'index à partir de 0  */
			var n = _this.getoptions(id);
			for( var i = 0; i < n.length; i++ ){
				if( i == index ){
					_this.set(n[i]);
					break;
				}
			}
			return 0;					
		};
		
		_this.gettext = function(id){				/* retourne le texte de l'élément de la liste sélectionné [options]  */
			var p = oEl.get(id).parentNode;
			var input = oEl.getclass("jaria_listlock", p)[0];
			return input.value.toString();
		};
		
		_this.setbytext = function(id, value){		/* sélectionne l'élément de la liste par le texte */
			var p = oEl.get(id).parentNode;
			var c = oEl.getclass("jaria_liste", p);
			var n = c[0].getElementsByTagName("*");
			for( var i = 0; i < n.length; i++ ){				
				var opt = oText.trim(n[i].innerHTML);					
				if( oText.trim(value) == opt ){
					value = _this.getoptionvalue(n[i]);	
					_this.set(n[i], value);
					break;
				}
			}
		};
				
		_this.setbyvalue = function(){		/* sélectionne l'élément de la liste par la valeur */
			/*
				argument 0 : obligatoire		élément ou id
				argument 1 : obligatoire		valeur de l'élément
			*/
			var el = ( oEl.isobject(arguments[0]) ) ? arguments[0] : oEl.get(arguments[0]);
			var opts = oEl.getclass("jaria_liste", el.parentNode)[0];			
			opts = oEl.gettags("div", opts);
			for( var i = 0; i < opts.length; i++ ){
				var opt = _this.getoptionvalue(opts[i]);
				if( oText.trim(arguments[1]) == opt ){
					_this.set(opts[i], opt);
					break;
				}
			}			
		};
		
		_this.getoptionvalue = function(opt){		/* retourne la valeur d'une option de la liste */
			if( typeof(opt) != "object"){
				return "";
			}
			return oText.trim(opt.getAttribute("data-value"));
		};

		_this.delalloptions = function(el, first){				/* détruit toutes les options des listes simples ou multiples */
			/*
				argument 0 : obligatoire		élément option
				argument 1 : facultatif			suppression depuis l' élément numéro...
			*/
			if( arguments.length == 0 ){
				return false;
			}
			if( !oEl.isobject(el) ){
				if( !oEl.test(el) ){
					return false;
				}
				el = oEl.get(el);					
			}
			if( typeof(first) != "number" || parseFloat(first) < 0 ){
				first = 0;
			}
			var p = el.parentNode;
			var d = oEl.gettags("div", p)[0];
			var e = oEl.gettags("input", p)[0];
			e.value = "";																			/* input text ou hidden selon le type de liste */
			if( e.type.toLowerCase() == "text" ){
				e.style.backgroundColor = _this.backgrounColor;	/* restitue la couleur de fond par défaut */				
				e = oEl.gettags("input", p)[1];									/* input hidden */
				e.value = "";
			}
			for( var i = d.childNodes.length - 1; i >= first; i-- ){
				d.removeChild(d.childNodes[i]);
			}
			if( d.childNodes.length > 0 ){
				if( d.className == "jaria_liste" ){
					_this.set(d.childNodes[0]);
				}else{
					_this.setm(d.childNodes[0]);
				}
			}

		};
		
		_this.addoption = function(el, value, text, style, fc){			/* ajoute une option à la liste */
			/*
				argument 0 : obligatoire		élément option
				argument 1 : obligatoire		valeur
				argument 2 : obligatoire		texte
				argument 3 : facultatif			fonction à lancer
			*/
			if( arguments.length < 3 ){
				return false;
			}
			if( !oEl.isobject(el) ){
				if( !oEl.test(el) ){
					return false;
				}
				el = oEl.get(el);					
			}
			if( typeof(value) != "string" ){
				value = "";
			}
			if( typeof(text) != "string" ){
				text = "";
			}
			var p = el.parentNode;
			var d = oEl.gettags("div", p)[0];
			var div = oEl.create("div");
			div.className = ( d.className == "jaria_mliste" ) ? "jaria_smliste" : "jaria_sliste";
			if( typeof(style) == "string"){
				var tab = (style).toString().split(";");
				for( var i = 0; i < tab.length; i++ ){
					try{
						eval("div.style." + tab[i]);
					}
					catch(e){}
				}
			}
			div.setAttribute("data-value", value);
			div.innerHTML = text;
			if( d.className == "jaria_mliste" ){
				div.onclick = function(){
					_this.setm(this);
				};	
			}
			else{
				div.onclick = function(){
					_this.set(this);
				};					
			}
			if ( typeof(fc) == "function" ){
				oNav.addevent("onclick", fc, div);
			}
			if ( typeof(fc) == "string" ){				
				oNav.addevent("onclick", eval(fc), div);
			}
			d.appendChild(div);
		};
	
		_this.resize = function(el){				/* redimentionne la liste déroulante pour supprimer d'eventuels retour à la ligne du texte des options */
			var tab = [];
			if( el.className == "jaria_liste" ){
				oEl.visible(el, true);
				var h = _this.getheightoptions(el, 200);
			}
			el.style.height = oText.toPx(h);
		};		
		
		_this.ombre = function(el){				/* ajoute l'ombre à la liste [options] */
			div = oEl.create("div");
			div.className = "jaria_ombre";
			div.style.width = oText.toPx(oEl.getoffset(el, "offsetWidth") -5);
			div.style.height = oText.toPx(oEl.getoffset(el, "offsetHeight") -5);
			div.style.left = oText.toPx(oEl.getoffset(el, "offsetLeft"));
			div.style.top = oText.toPx(oEl.getoffset(el, "offsetTop"));
			oEl.opacity(div, 30);	
			el.parentNode.appendChild(div);			
		};
		
		_this.checked = function(el){
			return ( el.className == "jaria_smlistecheck" ) ? true : false;
		};
		
		_this.setm = function(){					/* sélectionne une ou toutes les options de la liste multiple */
			/*
				argument 0 : obligatoire		élément
			*/
			if( arguments.length == 0 ){
				return false;
			}
			var opt = arguments[0];
			var value = opt.getAttribute("data-value");	
			
			if( !oEl.isobject(arguments[0]) || typeof(value) != "string"){
				return false;
			}
			var parent = opt.parentNode;
			var opts = parent.childNodes;
			var hid = oEl.gettags("input", parent.parentNode)[0];
			hid.value = "";
			if( oText.trim(value) == "*" ){					/* sélectionne ou déselectionne tout */
				var cl = ( _this.checked(opt) ) ? "jaria_smliste" : "jaria_smlistecheck";
				for( var i = 0; i < opts.length; i++ ){
					if( opts[i].nodeType == 1  ){
						opts[i].className = cl;
						if( _this.getoptionvalue(opts[i]) != "*" && _this.checked(opts[i]) ){
							hid.value += ( hid.value == "" ) ? _this.getoptionvalue(opts[i]) : "," + _this.getoptionvalue(opts[i]);
						}
					}
				}
				return false;
			}
			/* sélectionne l'otpion et renseigne les valeurs des options sélectionnées */
			opt.className = ( _this.checked(opt) ) ? "jaria_smliste" : "jaria_smlistecheck";
			for( var i = 0; i < opts.length; i++ ){
				if( opts[i].nodeType == 1  ){
					if( _this.getoptionvalue(opts[i]) == "*" ){
						opts[i].className = "jaria_smliste";
					}else{
						if( _this.checked(opts[i]) ){
							value = (_this.getoptionvalue(opts[i])).toString().replace(/"/g, "");
							hid.value += ( hid.value == "" ) ? value : "," + value;
						}
					}
				}
			}			
		};
		
		_this.setmbyvalue = function(){			/* sélectionne le(s) option(s) de la liste multiple par la valeur */
			/*
				argument 0 : obligatoire		identifiant de l'élément
				argument 1 : obligatoire		valeur(s) séparées par une virgule
			*/
			var el = ( oEl.test(arguments[0]) ) ?  oEl.get(arguments[0]) : undefined;
			var value = ( oText.test(arguments[1]) ) ? oText.trim(arguments[1]) : "";
			if( !oEl.isobject(el) ){
				return false;
			}
			var parent = el.parentNode;
			opts = oEl.gettags("div", oEl.gettags("div", parent)[0]);
			el.value = value;
			var tab = value.toString().split(",");
			for( var i = 0; i < opts.length; i++){
				var val = _this.getoptionvalue(opts[i]);
				opts[i].className = "jaria_smliste";
				if( val != "*" ){					
					for( var y = 0; y < tab.length; y++ ){
						if( oText.trim(tab[y]) == oText.trim(val) ){
							opts[i].className = "jaria_smlistecheck";
						}
					}
				}
			}		
		};
		
		_this.search = function(el, evt, file, name){		/* champ spécial de recherche progressive de données par Ajax */
			/* 
				argument 0 : obligatoire		élément
				argument 1 : obligatoire		évènement
				argument 2 : obligatoire		fichier host
				argument 3 : obligatoire		nom du paramètre à passer
			*/
			
			if( !oEl.test(el.id) ){
				return false;
			}
			var parent = el.parentNode;
			
			function hide(){					/* cache la liste */
				oEl.deltags("br", parent);
				oEl.deltags("div", parent);
			}			
			
			var value = oText.trim((el.value).toString().toUpperCase());
			if (value == ""){
				hide();
				return false;
			}
			_this.el = el;			
			var id = (el.id).toString();
			var height = 0;

			oAjax.recept = function(xml){					/* affiche le resultat dans la liste */
				var br = oEl.create("br");
				var div = oEl.create("div");
				div.className = "jaria_liste";
				div.style.width = _this.el.style.width;
				parent.appendChild(br);
				oNav.addevent("onmouseover", _this.mouseover);
				oNav.addevent("onmouseout", _this.mouseout);
				var tags = oEl.gettags("RESULT", xml);
				switch (tags.length){
					case 0:
						break;
					case 1:
						_this.el.value = oEl.gettags("RESULT", xml)[0].firstChild.nodeValue;
						break;
					default:
						for ( var i = 0; i < tags.length; i++ ){
							var sdiv = oEl.create("div");
							sdiv.className = "jaria_sliste";
							sdiv.innerHTML = oEl.gettags("RESULT", xml)[i].firstChild.nodeValue;
							sdiv.onclick = function(){
								var parent = this.parentNode.parentNode;	
								var input = oEl.gettags("input", parent)[0];	
								input.value = this.innerHTML;								
								oEl.deltags("br", parent);
								oEl.deltags("div", parent);
							};
							div.appendChild(sdiv);							
						}
						parent.appendChild(div);
						var height = ( i * 16 > 200 ) ? 200 : i * 16;			
						div.style.height = oText.toPx(height);
						oEl.visible(div, true);
						_this.ombre(div);
				}
				oEl.delclass(_this.el, "jaria_listesearch");
			};
			hide();
			if(evt.keyCode == 13){
				return false;
			}
			oEl.addclass(_this.el, "jaria_listesearch");
			
			/* initialise l'objet Ajax, envoi la valeur du champ de saisi et attend le retour host dans la fonction result */
			oAjax.init();
			oAjax.adddata(name, value);
			oAjax.send(file, "POST");			
			oAjax.onready("xml");
			/* ********************************** */
		};
		
		this.keydown = function(e){						// déploie la liste sur la touche flèche bas / haut
			e = e || window.event;
			var el = ( window.event ) ? e.srcElement : e.target;
			if( (e.keyCode == 40 || e.keyCode == 38 || e.keyCode == 13 ) && oText.lower(el.tagName) == "input" && el.className == "jaria_listlock" ){
				if( e.keyCode == 13 ){
					_this.hide();
				}
				else{
					_this.get(el, e);
				}
			}			
		};
	
		/* redéfini la fonction oNav.hideallbox pour prendre en compte la fermeture de la liste dans l'événement de la touche ESCAPE */
		var fn = oNav.hideallbox;
		oNav.hideallbox = function(){
			fn();
			_this.hide();
		};
		
		this.hideliste = function(e){					// referme les éventuelles listes ouvertes
			if( !oNav.ready ){
				return false;
			}			
			var el = e.target || window.event.srcElement;
			if( el.className.toString().indexOf("jaria_list") == -1 && el.className.toString().indexOf("jaria_slist") == -1 ){
				oEl.list.hide();
			}
		};
		
		oNav.addevent("onclick", _this.hideliste);
		oNav.addevent("onkeydown", _this.keydown)
		
	}