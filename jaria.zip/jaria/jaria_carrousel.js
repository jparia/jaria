	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* Le carrousel d'images */
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oCarrousel = new Carrousel();						/* Objet carrousel */
	
	function Carrousel(){
		
		var _this = this;
		
		this.path = "";				/* chemin des images (réduites) du carrousel */
		this.fullpath = "";			/* chemin des images (normales) du carrousel */
		this.el = undefined;		/* élement conteneur du carrousel */
		this.space = 30;			/* décalage entre les photos en pixels (de 0 & 100) */
		this.opacity = 75;			/* opacité des photos du carrousel (de 20 à 100) */
		this.milieu = 0;			/* image centrale */
		this.zIndex = 0;        	/* index de l'image */
		this.timer = null;			/* timer du carrousel */
		this.marginLeft = 0;		/* marge gauche réelle du carrousel */
		this.marginTop = 0;		  	/* marge haute réelle du carrousel */
		this.eti = undefined;   	/* étiquette de l'image centrale du carrousel */
		
		this.move = function(){
			return false
		};
		
		this.getimgbyalt = function(){						/* retourne l'élément image par son N° stocké dans l'attribu alt */
			/* images du conteneur */
			imgs = oEl.gettags("img", _this.el);
			for( var i = 0; i < imgs.length; i++ ){
				if(parseInt(arguments[0]) == getid(imgs[i].id) ){
					return imgs[i];				
				}				
			}
			return undefined;
		};
		
		function getid(id){		
			return parseInt(parseFloat(id));
		};
		
		this.play = function(){                   /* démarre l'animation du carrousel */
		
			if( _this.timer != null ){
				return false;
			}
			
			_this.move = function(){		/* redéfini la fonction .move */
			
				/* mémorise la position initiale de la dernière image avant déplacement */
				var endTop = parseFloat(imgs[imgs.length -1].style.top);
				var endLeft = parseFloat(imgs[imgs.length -1].style.left);
				
				/* on décale les images de la droite vers la gauche (de la dernière vers la première) */
				for( var i = imgs.length; i > 0; i-- ){
					
					var imgec = _this.getimgbyalt(i);												/* image du N° en cours */
					imgec.className = "jaria_carrousel_img";
					if( getid(imgec.id) == 1 && parseFloat(imgec.style.left) == _this.marginLeft ){						
						/* on déplace la première image de gauche vers la dernière initialement positionnée à droite */
						imgec.style.left = (endLeft).toString() + "px";
						imgec.style.top = (endTop).toString() + "px";
						imgec.style.zIndex = 1;
						imgec.id = (imgs.length).toString();
						div = imgec;
						_this.el.removeChild(imgec);
						_this.el.appendChild(imgec);
						break;
					}else{
						/* on déplace l'image en cours sur l'image précédent à gauche */
						var imgprec = _this.getimgbyalt( getid(imgec.id) -1 );		/* image précédente du N° en cours */
						oEl.drag.X = parseFloat(imgprec.style.left);
						oEl.drag.Y = parseFloat(imgprec.style.top);
						imgec.style.top = imgprec.style.top;
						imgec.style.left = imgprec.style.left;
						imgec.style.zIndex = imgprec.style.zIndex;
						imgec.id = (getid(imgec.id) - 1).toString() + "_jaria_caroussel";
					}					
					if( i == _this.milieu + 1 ){
						imgec.className = "jaria_carrousel_imgm";
						_this.eti.innerHTML  = imgec.alt;
						oEl.fader.plus(imgec, 30);
					}else{
						oEl.opacity(imgec, parseInt(_this.opacity) / 2);
					}
				}
			};
			
			/*	argument 0:	N° de l'image	*/			
			if( ! oEl.isobject(_this.el) ){
				return false;
			}			
			/* images du conteneur */
			var imgs = oEl.gettags("img", _this.el);
			_this.timer = window.setInterval(_this.move, 700);
			
			return true;
			
		};
		
		this.show = function(){     /* Créé le carouselle d'images */
	
			/*	argument 0:	élement recevant le carrousel
				arguments suivants: photos du carrousel
			*/
	
			if( arguments.length < 2 ){
				return false;
			}
			var el = arguments[0];
			if( !oEl.isobject(el) ){
				if( oEl.test(el) ){
					el = oEl.get(el);
				}else{
					return false;
				}
			}
			_this.hide();						/* détruit un eventuel carrousel existant */
			_this.el = oEl.create("div");			/* création du conteneur */
			_this.el.className = "jaria_carrousel";
			el.appendChild(_this.el);
			_this.marginLeft = parseInt(oNav.marginLeft) + parseInt(oEl.getoffset(_this.el, "offsetLeft"));
			_this.marginTop = parseInt(oNav.marginTop) + parseInt(oEl.getoffset(_this.el, "offsetTop"));	
			_this.milieu = Math.round( (arguments.length -1) / 2 );
			if( _this.fullpath == "" ){
				_this.fullpath = _this.path;
			}
			for ( var i = 1; i < arguments.length; i++ ){				
				var img = oEl.create("img");
				img.src = _this.path + arguments[i];
				img.className = "jaria_carrousel_img";
				img.id = (i).toString() + "_jaria_caroussel";
				img.alt = arguments[i];
				if( _this.space < 0 || _this.space > 100 ){
					_this.space = 75;
				}
				if( _this.opacity  < 20 || _this.opacity > 100 ){
					_this.opacity = 30;
				}
				_this.el.appendChild(img);
				var left = ( i == 1 ) ? _this.marginLeft : _this.marginLeft + ( (i -1) * (parseFloat(oEl.getstyleclass(img, "width")) - _this.space) );
				if( isNaN(left) ){break;}
				img.style.left = (left).toString() + "px";
				if( i <= _this.milieu ){
					img.style.zIndex = i;
					img.style.top = (_this.marginTop + (5 * (i -1))).toString() + "px";
				}else{
					var y = _this.milieu - (i - _this.milieu);					
					img.style.zIndex = y;
					img.style.top = (_this.marginTop + (5 * (y -1))).toString() + "px";
				}				
				oEl.opacity(img, _this.opacity);				
				if( i == _this.milieu ){
					oEl.opacity(img, 100);
					img.className = "jaria_carrousel_imgm";					
					/* on ajoute l'étiquette du nom de l'image centrale */
					_this.eti = oEl.create("div");
					img.className = "jaria_carrousel_imgm";			
					_this.eti.className = "jaria_carrousel_eti";
					_this.eti.style.zIndex = (i+1);
					_this.eti.style.top = ( parseFloat(img.style.top) + parseFloat(oEl.getstyleclass(img, "height")) + 5  ).toString() + "px";
					_this.eti.style.left = ( oEl.getoffset(img, "offsetLeft") ).toString() + "px";
					_this.eti.innerHTML = arguments[i];
					_this.el.appendChild(_this.eti);
				}
				img.onmouseover = function(){
					this.style.cursor = (getid(this.id) == _this.milieu ) ? "pointer" : "e-resize";
					var e = ( getid(this.id) == _this.milieu ) ? _this.stop() : _this.play();
					return true;
				};
				img.onmouseout = function(){					
					_this.stop();
					return true;
				};
				img.onclick = function(){
					if( getid(this.id) == _this.milieu ){
						_this.click(this);						
					}
					return true;
				};						
			}
		};
	
		this.stop = function(){       /* arrête l'animation du carrousel */
			try{
				window.clearInterval(_this.timer);
			}catch(e){}
			_this.timer = null;
			/* images du conteneur */
			imgs = oEl.gettags("img", _this.el);
			for( var i = 0; i < imgs.length; i++ ){
				oEl.opacity(imgs[i], _this.opacity);
				if( i == _this.milieu -1 ){ 
					oEl.opacity(imgs[i], 100);
				}
			}
		};
		
		this.hide = function(){						/* détruit le carrousel */
			if( ! oEl.isobject(_this.el) ){
				return false;
			}
			_this.el.parentNode.removeChild(_this.el);
			this.el = undefined;			
		};
		
		this.click = function(obj){					/* fonction du click sur l'image centrale pouvant être redéfinie */
			/* on affiche l'image centrale */
			oBox.hide();
			oBox.posY = -100;
			oBox.ico = 0;
			oBox.title = obj.alt;
			oBox.bts = 0;		
			oBox.html = "<div style='text-align:center;'><img style='border: 1px solid #333' src='" + _this.fullpath + obj.alt + "' alt='' /></div>";
			oBox.html += "<div style='text-align:center;'>" + _this.fullpath + obj.alt + "</div>";
			oBox.backColor = "#FFFFFF";
			oBox.show();
			oBox.el.className = "jaria_box jaria_diap_box";
			oBox.el.Quit.className = "jaria_boxferme jaria_diap_boxferme";
			oBox.el.Title.className = "jaria_boxtitre jaria_diap_boxtitre";
			oBox.el.Head.className = "jaria_boxhead jaria_diap_boxhead";
		};
	}