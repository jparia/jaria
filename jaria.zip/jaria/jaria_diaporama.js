	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* Le diaporama d'images */
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oDiapo = new Diapo();					/* Objet diaporama d'images */
	
	function Diapo(){									/* box diaporama */
	
		var _this = this;
				
		this.timer = null;							/* timer pour le défilement du diaporama */
		this.index = 0;									/* index de l'image en cours de 0 à ...*/
		this.path = "images/";					/* chemin des images */
		this.images = new Array();
		this.imgs = new Array();				/* tableau des noms des images passées en paramètre à la fonction Diapo.show() */
		this.loaded = false;						/* images chargées */
		this.liens = new Array();				/* tableau des liens du sélecteur d'images */
		this.delai = 3;									/* délai de défilement en seconde */
		this.conteneur = undefined;			/* conteneur image */
		this.button = undefined;				/* bouton play and stop */
		this.title = "";								/* texte de la barre de titre du diaporama */
		this.width = null;							/* largeur image(s) */
		this.height = null;							/* hauteur image(s) */
		this.posX = 0;									/* modifie la position horizontale */
		this.posY = 0;									/* modifie la position verticale */
		this.modal = true;							/* empêche toute action sur la page */
		this.loop = false;
	
		this.loadImage = function(){			/* préchargement de l'image en cours */
		
		
			if( !oEl.isobject(_this.imgs[_this.index]) ){
				var img = _this.imgs[_this.index];
				_this.imgs[_this.index] = new Image();
				_this.imgs[_this.index].src = _this.path + oText.trim(img);
				_this.conteneur.innerHTML = "chargement de l'image " + _this.index + " / " +_this.imgs.length;
			}
						
			if( _this.imgs[_this.index].complete ){				
				if( _this.index == _this.imgs.length -1 ){
					_this.conteneur.innerHTML = "";
					_this.conteneur.appendChild(_this.imgs[0]);									
					/* dimensions de la première image */
					_this.setSize(0);	
					_this.Selecteur();	
					return false;		
				}
				_this.index++;
			}
			
			_this.timer = window.setTimeout(_this.loadImage, 100);
			
		};
		
		this.setSize = function(index){
			var div = oEl.create("div");
			div.style.textAlign = "center";
			if( !isNaN(_this.imgs[index].naturalWidth) && !isNaN(_this.imgs[index].naturalHeight) ){
				div.innerHTML = _this.imgs[index].naturalWidth.toString() + " x " + _this.imgs[index].naturalHeight.toString() + " pixels";
			}
			else{
				div.innerHTML = _this.imgs[index].width.toString() + " x " + _this.imgs[index].height.toString() + " px";
			}
			_this.conteneur.appendChild(div);
		};
		
		this.stop = function(){					/* arrêt du défilement des images du diaporama */
			oNav.init_timer(_this.timer);
			_this.timer = null;
			if( oEl.isobject(_this.button) ){
				_this.button.className = "jaria_diap_button jaria_diap_button_play";
				_this.button.title = "Play";
				_this.button.onclick = _this.play;
			}
		};
		
		this.play = function(){					/*démarrage du défilement des images du diaporama */
			if( oEl.isobject(_this.button) ){
				_this.button.className = "jaria_diap_button jaria_diap_button_stop";				
				_this.button.title = "Stop";
				_this.button.onclick = _this.stop;
			}
			_this.loop = true;
			_this.timer = window.setInterval(_this.change, (parseInt(_this.delai) * 1000));			
		};
		
		this.change = function(){				/* change l'image */
			
			if( !oBox.exist ){				
				_this.hide();								/* dans le cas ou la box est fermé par la touche esc */
				return false;
			}
			
			_this.conteneur.innerHTML = "";
						
			if( _this.loop ){
				_this.index ++;
			}
			else{
				_this.stop();
			}
			
			if (_this.index >= _this.imgs.length){				
				_this.index = 0;				/* on redémarre à la première image */
			}
			for( var i = 0; i < _this.imgs.length; i++ ){	
				_this.liens[i].className = "jaria_diap_lien";
				if( i == _this.index ){
					_this.liens[i].className = "jaria_diap_lienov";					
					_this.conteneur.appendChild(_this.imgs[i]);
					_this.setSize(i);
					oBox.setshadow();
				}
			}
			
			var temp = ( parseInt(_this.delai) <= 10 ) ? (parseInt(_this.delai) * 10) : 10;
			oEl.fader.plus(_this.imgs[_this.index], temp);
		};
		
		this.Selecteur = function(){			/* création du sélecteur d'accès aux images */
			
			if( _this.imgs.length < 2 ){
				return false;
			}			
			
			var div = oEl.create("div");
			div.className = "jaria_diap_buttons";
			_this.button = oEl.create("span");
			_this.button.className = "jaria_diap_button jaria_diap_button_play";
			_this.button.innerHTML = "&nbsp;";
			_this.button.title = "Play";
			_this.button.onclick = _this.play;
			div.appendChild(_this.button);
			_this.liens = new Array();
			
			for( var i = 0; i < _this.imgs.length; i++ ){
				
				_this.liens[i] = oEl.create("span");
				_this.liens[i].className = "jaria_diap_lien";		
						
				_this.liens[i].onclick = function(){
					/* affiche la photo sélectionnée */
					_this.index = parseInt(this.innerHTML) -1;
					_this.loop = false;
					_this.change();
				};	
														
				_this.liens[i].innerHTML = (i+1).toString();
				div.appendChild(_this.liens[i]);							
			}	
			
			_this.liens[0].className = "jaria_diap_lienov";
			oBox.el.Html.appendChild(div);
			oBox.setshadow();			
		};
		
		this.show = function(){					/* créé et affiche le diaporama */
		
			this.hide(0);	
					
			if( isNaN(_this.delai) ){
				_this.delai = 3;	  
			}
			
			/* le(s) nom(s) des images doivent-être passé(s) en paramètre */			
			if( arguments.length == 0 ){
				return false;
			}
			
			this.imgs = (arguments.length == 1 && arguments[0].toString().split(",").length > 1) ? arguments[0].toString().split(",") : arguments;
			
			if(this.imgs.length == 0){
				return false;
			}
			
			/* initialise la box avant transformation */
			oBox.html = "&nbsp;";
			oBox.bts = 0;
			oBox.title = (oText.trim(_this.title) != "") ? oText.trim(_this.title) : "diaporama";
			oBox.width = ( !isNaN(_this.width) ) ? parseInt(_this.width + 50) : 400;
			oBox.posX = ( !isNaN(_this.posX) ) ? parseInt(_this.posX) : 0;
			oBox.posY = ( !isNaN(_this.posY) ) ? parseInt(_this.posY) : 0;
			oBox.borderColor = "#424343";
			oBox.backColor = "#6E6F6F";
			oNav.lock.anim = 0;
			oNav.lock.color = "#6E6F6F";
			oBox.show();
			
			if(!this.modal){
				oNav.lock.hide();
			}
			
			oBox.el.Quit.onclick = _this.hide;
			
			/* création du conteneur d'images */
			this.conteneur = oEl.create("div");
			this.conteneur.className = "jaria_diapo_conteneur";
			oBox.el.Html.appendChild(this.conteneur);		
			
			/* préchargement des images */
			this.loadImage();						
		};
		
		this.hide = function(){						/* détruit le diaporama */
			_this.stop();
			_this.imgs = new Array();
			_this.index = 0;
			if( arguments.length == 0){
				_this.title = "";
				_this.width = null;
				_this.height = null;
			}
			oBox.hide();
		};

		this.load = function(){
			oNav.loadimg(
				jaria.images + "diapo/play.png",
				jaria.images + "diapo/stop.png"
			);			
		};
		
	}
	
	oNav.addevent("onload", function(){
		oDiapo.load();
	});	