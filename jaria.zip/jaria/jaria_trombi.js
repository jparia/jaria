	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* Le trombinoscope */

	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oTrombi = new Trombi();						/* Objet trombinoscope */
	
	function Trombi(){		
	
		var _this = this;
		
		_this.pathXml = "";			/* chemin du fichier xml des données */
		_this.pathImg = "";			/* chemin des images (réduites) du trombinoscope */
		_this.pathImgFull = "";		/* chemin des images (agrandies) du trombinoscope */
		_this.el = undefined;		/* élement conteneur du trombinoscope */
		_this.count = 0;				/* numéro du compte en cours */
		_this.timer = null;			/* timer du trombinoscope */
		_this.delai = 2;				/* délai d'affichage en mode Play (en seconde) de 2 à 10 secondes */ 
		_this.marginLeft = 0;		/* marge gauche réelle du trombinoscope */
		_this.marginTop = 0;		  	/* marge haute réelle du trombinoscope */
		_this.background = "";		/* image de fond du trombinoscope */

		_this.LoadXml = function(){
			/* format du XML:
				<TROMBINOSCOPE>
					<COMPTE nom="nom1" prenom="prenom1" photo="photo1.jpg">
						<INFOS label="label1">valeur1</INFOS>
						<INFOS label="label2">valeur2</INFOS>
						<INFOS ...
					</COMPTE>
					<COMPTE nom="nom2" prenom="prenom2" photo="photo2.jpg">
						<INFOS label="label1">valeur1</INFOS>
						<INFOS label="label2">valeur2</INFOS>
						<INFOS ...
					</COMPTE>
					<COMPTE ...
				</TROMBINOSCOPE>
			*/
			var xmlDoc;			

			if (window.XMLHttpRequest){
				xhttp=new XMLHttpRequest();
				xhttp.open("GET",_this.pathXml,false);
				xhttp.send("");
				xmlDoc = xhttp.responseXML; 
				return xmlDoc;
			}else if (window.ActiveXObject){	/* pour IE 6 */
				xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
				xmlDoc.async = false;
				xmlDoc.load(_this.pathXml);
				return xmlDoc;
			}else{
				return undefined;
			}
		};
		
		_this.setInfos = function(){
			/* 
				arguments 0: Node parent
			*/
			var el = arguments[0];
			var nom = el.getAttribute("nom");
			var prenom = el.getAttribute("prenom");
			_this.el.divt.innerHTML = nom + " " + prenom;
			var tabNodes = oEl.gettags("INFOS", el);
			var el = _this.el.divl;
			el.innerHTML = "";
			for ( var i = 0; i < tabNodes.length; i++ ){
				var div = oEl.create("div");
				div.className = "jaria_trombi_info";
				var divl = oEl.create("div");
				divl.className = "jaria_trombi_infoleft";
				divl.innerHTML = tabNodes[i].getAttribute("label") + ":";
				var divr = oEl.create("div");
				divr.className = "jaria_trombi_inforight";
				divr.innerHTML = tabNodes[i].firstChild.nodeValue;				
				div.appendChild(divl);
				div.appendChild(divr);
				el.appendChild(div);
			}
		};
		
		_this.setCount = function(){
			_this.el.divcount.innerHTML = (_this.count + 1).toString() + " / " + (arguments[0]).toString();
		};
		
		_this.setPhoto = function(){
			/* 
				arguments 0: Node parent
			*/
			var el = _this.el.divr;
			el.innerHTML = "";
			var photo = arguments[0].getAttribute("photo");
			var img = oEl.create("img");
			img.src = _this.pathImg + photo;
			img.className = "jaria_trombi_photo";
			img.alt = "";
			if( _this.pathImgFull != "" ){		/* photo agrandie */
				img.onclick = _this.loupe;
				img.style.cursor = "pointer";
			}			
			el.appendChild(img);
			oEl.fader.plus(el, 50);
		};
		
		_this.first = function(){     /* premier */
			_this.stop();
			var oXml = _this.LoadXml();
			if( oEl.isobject(oXml) ){
				var c = oEl.gettags("COMPTE", oXml);
				_this.setPhoto(c[0]);
				_this.setInfos(c[0]);
				_this.count = 0;
				_this.setCount(c.length);				
			}
		};

		_this.next = function(){     /* passe au suivant */

  		var i = _this.count + 1;
			var oXml = _this.LoadXml();
			if( oEl.isobject(oXml) ){
				var c = oEl.gettags("COMPTE", oXml);
				if( i > c.length -1 ){
					return false;
				}
				_this.setPhoto(c[i]);
				_this.setInfos(c[i]);
				_this.count ++;
				_this.setCount(c.length);		
			}
			if( isNaN(arguments[0]) ){
				_this.stop();
			}
		};
		
		_this.nextauto = function(){
				_this.next(1);
				_this.timer = window.setTimeout(_this.nextauto, (_this.delai * 1000));
		};
		
		_this.previous = function(){  /* passe au précedent */
			_this.stop();
			var i = _this.count - 1;
			if ( i < 0 ){
				return false;
			}
			var oXml = _this.LoadXml();
			if( oEl.isobject(oXml) ){
				var c = oEl.gettags("COMPTE", oXml);
				_this.setPhoto(c[i]);
				_this.setInfos(c[i]);
				_this.count --;
				_this.setCount(c.length);				
			}		
		};
		
		_this.last = function(){     /* dernier */
			_this.stop();
			var i = _this.count;
			var oXml = _this.LoadXml();
			if( oEl.isobject(oXml) ){
				var c = oEl.gettags("COMPTE", oXml);
				if( i >= c.length -1 ){
					return false;
				}
				var i = c.length -1;
				_this.setPhoto(c[i]);
				_this.setInfos(c[i]);
				_this.count = i;
				_this.setCount(c.length);
				
			}
		};
		
		_this.setplay = function(state){
			var img = oEl.create("img");
			img.src = jaria.images + "button/button_" + state + ".png";
			img.alt = "";
			img.title = state;
			img.style.marginTop = "3px";
			_this.el.btplay.innerHTML = "";
			_this.el.btplay.appendChild(img);
			_this.el.btplay.onclick = ( state == "play" ) ?  _this.play : this.stop;
		};
		
		_this.play = function(){    /* démarre l'animation du trombinoscope */
			if( _this.timer != null ){
				return false;
			}	
			_this.setplay("stop");
			_this.nextauto();
			return true;
		};

		_this.stop = function(){       /* arrête l'animation du trombinoscope */
			try{
				window.clearInterval(_this.timer);
			}catch(e){}
			_this.timer = null;
			_this.setplay("play");
		};
		
		_this.show = function(){     /* Créé le carouselle d'images */
	
			/* argument 0:	élement parent recevant le trombinoscope */
	
			if( arguments.length == 0 ){
				return false;
			}
			var el = arguments[0];
			if( !oEl.isobject(el) ){
				if( oEl.test(el) ){
					el = oEl.get(el);
				}else{
					return false;
				}
			}
			_this.delai = ( _this.delai >=2 && _this.delai <= 10 ) ? _this.delai : 2;
			_this.hide();						/* détruit un eventuel trombinoscope existant */
			_this.el = oEl.create("div");		/* création du conteneur */
			_this.el.className = "jaria_trombi";
			if( _this.background != "" ){
				_this.el.style.backgroundImage = "url(" + _this.background + ")";
			}
			el.appendChild(_this.el);
			_this.marginLeft = parseInt(oNav.marginLeft) + parseInt(oEl.getoffset(_this.el, "offsetLeft"));
			_this.marginTop = parseInt(oNav.marginTop) + parseInt(oEl.getoffset(_this.el, "offsetTop"));	
			/* conteneur du compte */
			_this.el.divt = oEl.create("div");
			_this.el.divt.className = "jaria_trombi_top";
			/* conteneur des infos */
			_this.el.divl = oEl.create("div");
			_this.el.divl.className = "jaria_trombi_left";
			/* conteneur de la photo */
			_this.el.divr = oEl.create("div");
			_this.el.divr.className = "jaria_trombi_right";
			/* conteneur de la barre de navigation */
			_this.el.divb = oEl.create("div");
			_this.el.divb.className = "jaria_trombi_barre";
			_this.el.appendChild(_this.el.divt);
			_this.el.appendChild(_this.el.divl);
			_this.el.appendChild(_this.el.divr);
			_this.el.appendChild(_this.el.divb);
			/* boutons */
			_this.el.btplay = oEl.create("button");
			_this.el.btplay.className = "jaria_trombi_button";
			_this.el.btplay.title = "Boucler / Stopper";			
			_this.setplay("play");
			var bfirst = oEl.create("button");
			bfirst.className = "jaria_trombi_button";
			bfirst.innerHTML = "|&lt;";
			bfirst.title = "|< Premier";
			bfirst.onclick = _this.first;
			var bprev = oEl.create("button");
			bprev.className = "jaria_trombi_button";
			bprev.innerHTML = "&lt;";
			bprev.title = "< Précédent";
			bprev.onclick = _this.previous;
			var bnext = oEl.create("button");
			bnext.className = "jaria_trombi_button";
			bnext.innerHTML = "&gt;";
			bnext.title = "Suivant >";
			bnext.onclick = _this.next;
			var blast = oEl.create("button");
			blast.className = "jaria_trombi_button";
			blast.innerHTML = "&gt;|";
			blast.title = "Dernier >|";
			blast.onclick = _this.last;
			/* conteneur du compteur de compte */
			_this.el.divcount = oEl.create("div");
			_this.el.divcount.className = "jaria_trombi_barre_count";
			_this.el.divcount.innerHTML = "0 / 0";
			_this.el.divb.appendChild(_this.el.btplay);
			_this.el.divb.appendChild(bfirst);
			_this.el.divb.appendChild(bprev);
			_this.el.divb.appendChild(bnext);
			_this.el.divb.appendChild(blast);
			_this.el.appendChild(_this.el.divcount);
			_this.first();
			oEl.opacity(_this.el.divl, 80);
		};
	
		_this.hide = function(){						/* détruit le trombinoscope */
			if( ! oEl.isobject(_this.el) ){
				return false;
			}
			_this.stop();
			_this.el.parentNode.removeChild(_this.el);
			_this.el = undefined;			
		};
		
		_this.loupe = function(){					/* fonction de loupe sur l'image */
			/* on affiche la photo agrandie */
			oBox = new Box();
			_this.stop();
			var oXml = _this.LoadXml();
			if( oEl.isobject(oXml) ){
				var i = _this.count;
				var c = oEl.gettags("COMPTE", oXml);
				var nom = c[i].getAttribute("nom");
				var prenom = c[i].getAttribute("prenom");
				var photo = c[i].getAttribute("photo");				
				oBox.posY = -100;
				oBox.ico = 0;
				oBox.title = nom + " " + prenom;
				oBox.bts = 0;
				oBox.html = "<div style='text-align:center;'><img style='border: 1px solid #333' src='" + _this.pathImgFull + photo + "' alt='' /></div>";
				oBox.backColor = "#FFFFFF";
				if( _this.background != "" ){
					oBox.backImage = _this.background;
				}
				oBox.show();
				oBox.el.className = "jaria_box jaria_diap_box";
				oBox.el.Quit.className = "jaria_boxferme jaria_diap_boxferme";
				oBox.el.Title.className = "jaria_boxtitre jaria_diap_boxtitre";
				oBox.el.Head.className = "jaria_boxhead jaria_diap_boxhead";
			}
		};
	}
