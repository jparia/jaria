﻿	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library 'Jaria' is not loaded!");
	}
	
	if( typeof(List) != "function" ){
		alert("The JavaScript library 'jaria_list' is not loaded");
	}

	
	/* Le panel des dates */
	
	oCal.datepicker = new DatePicker();
	
	function DatePicker(){										/* calendrier mensuel avec selecteurs mois & année */
	
		var _this = this;
		var oList = new List();
		
		this.el = undefined;
		this.left = null;
		this.top = null;
		this.date = null;
		this.day = null;
		this.year = null;
		this.id = "";
		
		this.drag = function(event){					/* démarrage du déplacement du calendrier */
			oEl.drag.opacity = 65;
			oEl.drag.start(_this.el, event);
		};
			
		this.set = function(){								/* retourne la date sélectionnée */
			if(!oEl.test(_this.id)){
				return false;	
			}
			var day = parseInt(this.innerHTML);
			var month = parseInt(_this.el.selmonth.value);
			var year = parseInt(_this.el.selyear.value);
			if( day.toString().length == 1 ){
				day = ( "0" + day ).toString();
			}
			month = oText.daymonth(month);
			var date = (day + "/" + month + "/" + year).toString();
			var input = oEl.get(_this.id);
			if( oText.trim(input.value) != date ){
				input.value = date;
			}
			_this.valid();
			_this.hide();
		};
			
		this.get = function(){								/* actualise le calendrier selon le mois et l'année sélectionnée */
			var date = new Date();
			var day = parseInt(1);
			this.month = parseInt(this.el.selmonth.value) -1;
			this.year = parseInt(this.el.selyear.value);
			this.date.setDate(day);
			this.date.setMonth(this.month);
			this.date.setFullYear(this.year);
			this.day = date.getDate();
			if( (this.month != date.getMonth()) || (this.year != date.getFullYear()) ){
				this.day = -1;
			}
			this.left = parseFloat(this.el.style.left);
			this.top = parseFloat(this.el.style.top);
			this.show(this.id, true);		
		};
			
		this.getdate = function(id){						/* date actuelle ou celle du champ date */
			this.date = new Date();
			if( this.day == null ){
				this.day = this.date.getDate();
			}
			if( oCal.isdate(oEl.get(id).value) ){			
				var date = (oEl.get(id).value).toString();
				var tab = date.split("/");
				this.date.setDate( parseFloat(tab[0]) );
				this.date.setMonth( parseFloat(tab[1])-1 );
				this.date.setFullYear( parseFloat(tab[2]) );
				this.day = this.date.getDate();
			}
			this.month = this.date.getMonth();
			this.year = this.date.getFullYear();
			if( (this.month != this.date.getMonth()) || (this.year != this.date.getFullYear()) ){
				this.day = -1;
			}
		};			
			
		this.show = function(id, st){							/* créé et affiche le datepicker */
			if(!oEl.test(id) || !oNav.ready){
				return false;	
			}
			_this.hide();
			oNav.hideallbox();
			oText.select(false);
			var date, days, daysletter, firstweek, months, daysthismonth, thismonth, nextmonth, div, sdiv, tb, tbo, tr, td, input, sel, opt, hid;
			days = new Array( "D", "L", "M", "M", "J", "V", "S" );
			daysletter = new Array( "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi" );
			months = new Array( "Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre" );
			this.el = oEl.create("div");
			this.el.className = "jaria_cal_box";	
			if( st == null ){									/* si nouveau datepicker */
				this.left = null;
				this.top = null;
				this.date = null;
				this.day = null;
				this.year = null;
				this.id = id;
				this.getdate(id);
			}			
			thismonth = new Date(this.year, this.month, 1);
			nextmonth = new Date(this.year, (this.month + 1), 1);
			firstweek = thismonth.getDay();
			daysthismonth = Math.round( (nextmonth.getTime() - thismonth.getTime())/(1000 * 60 * 60 * 24) );
			div = oEl.create("div");
			div.className = "jaria_cal_head";
			div.onmousedown = this.drag;
			div.title = "clic droit ou [esc] pour quitter";
			div.oncontextmenu = this.hide;
			this.el.appendChild(div);
			div = oEl.create("div");
			div.style.width = "142px";
			div.style.paddingTop = "2px";
			div.style.height = "25px";
			
			/* Liste des mois */
			sel = oEl.create("div");
			br = oEl.create("br");
			input = oEl.create("input");
			sdiv = oEl.create("div");
			hid = oEl.create("input");
			div.style.textAlign = "center";
			sel.style.paddingLeft = "12px";
			
			sel.style.width = "55px";
			if( oNav.msie ){
				sel.style.styleFloat = "left";
			}else{
				sel.style.cssFloat = "left";
			}			
			input.className = "jaria_listlock";
			input.style.width = "50px";
			input.style.paddingRight = "3px";
			input.value = months[this.month].substr(0, 4); 
			input.readOnly = "readonly";
			input.onchange = this.get;			
			input.onclick = function(){
				var ombre = (oNav.msie) ? false : true;
				oList.get(this, ombre);
			};			
			sdiv.className = "jaria_liste";
			sdiv.style.height = "100px";
			hid.type = "hidden";
			hid.value = (this.month + 1).toString();			
			for( var i = 1; i <= 12; i++ ){
				opt = oEl.create("div");
				opt.setAttribute("data-value", i.toString());
				opt.onclick = function(){					
					oList.set(this);
					_this.get();
				};			
				opt.innerHTML = months[i-1].substr(0, 4);
				sdiv.appendChild(opt);
			}
			sel.appendChild(input);	
			sel.appendChild(br);	
			sel.appendChild(sdiv);			
			sel.appendChild(hid);
			div.appendChild(sel);
			this.el.selmonth = hid;
			
			/* Liste des années */
			var sel = oEl.create("div");
			var br = oEl.create("br");
			var input = oEl.create("input");
			var sdiv = oEl.create("div");
			var hid = oEl.create("input");
			div.style.textAlign = "left";
			sel.style.paddingLeft = "12px";
			sel.style.width = "55px";
			if( oNav.msie ){
				sel.style.styleFloat = "left";
			}else{
				sel.style.cssFloat = "left";
			}			
			input.className = "jaria_listlock";
			input.style.width = "50px";
			input.style.paddingRight = "3px";
			input.value = this.year.toString(); 
			input.readOnly = "readonly";
			input.onclick = function(){
				var o = (oNav.msie) ? false : true;
				oList.get(this, o);
			};			
			sdiv.className = "jaria_liste";
			sdiv.style.height = "100px";
			hid.type = "hidden";
			hid.value = this.year.toString();	
			var date = new Date();
			for( var i = (date.getFullYear()-50); i < (date.getFullYear()+10); i++){
				var opt = oEl.create("div");
				opt.setAttribute("data-value", i.toString());
				opt.onclick = function(){					
					oList.set(this);
					_this.get();
				};			
				opt.innerHTML = i.toString();
				sdiv.appendChild(opt);
			}
			sel.appendChild(input);	
			sel.appendChild(br);	
			sel.appendChild(sdiv);			
			sel.appendChild(hid);
			div.appendChild(sel);
			this.el.selyear = hid;			
			this.el.appendChild(div);
			div = oEl.create("div");
			div.style.width = "136px";
			div.align = "right";
			div.style.padding = "3px";
			tb = oEl.create("table");
			tb.className = "jaria_cal_tb";
			tbo = oEl.create("tbody");
			tr = oEl.create("tr");
			td = oEl.create("td");
			td.colSpan = 7;
			td.className = "jaria_cal_tdnoday";
			td.innerHTML = months[this.month] + " " + this.year;
			tr.appendChild(td);
			tbo.appendChild(tr);
			tr = oEl.create("tr");
			for( var i = 0; i < days.length; i++ ){
				td = oEl.create("td");
				td.className = "jaria_cal_tdday";
				td.innerHTML = days[i].toString();
				td.title = daysletter[i].toString();
				tr.appendChild(td);
			}
			tbo.appendChild(tr);
			tr = oEl.create("tr");
			for( var weekday = 0; weekday < firstweek; weekday++ ){
				td = oEl.create("td");
				td.className = "jaria_cal_tdnoday";
				td.innerHTML = "&nbsp;";
				tr.appendChild(td);
			}
			weekday = firstweek;
			for( var countday = 1; countday <= daysthismonth; countday++ ){
				weekday %= 7;
				if( weekday == 0 && countday > 1){
					tbo.appendChild(tr);
					tr = oEl.create("tr");
				}
				td = oEl.create("td");
				td.innerHTML = countday.toString();
				td.onclick = this.set;
				if(this.day == countday){
					td.className = "jaria_cal_tdday";
					td.onmouseover = function(){
						this.className = "jaria_cal_tddayov";
					};
					td.onmouseout = function(){
						this.className = "jaria_cal_tdday";
					};
				}else{
					td.className = "jaria_cal_tdoday";
					td.onmouseover = function(){
						this.className = "jaria_cal_tdodayov";
					};
					td.onmouseout = function(){
						this.className = "jaria_cal_tdoday";
					};
				}
				tr.appendChild(td);
				weekday++;
			}
			for( var i = weekday; i < 7 ; i++ ){
				td = oEl.create("td");
				td.className = "jaria_cal_tdnoday";
				td.innerHTML = "&nbsp;";
				tr.appendChild(td);
			}
			tbo.appendChild(tr);
			tb.appendChild(tbo);
			div.appendChild(tb);
			this.el.appendChild(div);
			oNav.body.appendChild(this.el);
			oNav.contextmenu(false, this.el);
			this.el.style.left = ( this.left == null) ? oText.toPx(oNav.mouse.X + oNav.scrollX) : oText.toPx(this.left);
			this.el.style.top = ( this.top == null) ? oText.toPx(oNav.mouse.Y + oNav.scrollY) : oText.toPx(this.top);
			this.inscreen();		
		};
		
		this.hide = function(){								/* cache le calendrier [hide]*/
			try{
				oNav.body.removeChild(_this.el);
			}catch(e){}
			oText.select(true);
			oNav.contextmenu(true);
			_this.valid = function(){};
		};
		
		this.valid = function(){
			/* Action supplémentaire à effectuer sur le choix d'une date */	
		};
		
		this.inscreen = function(){
			 oEl.setinscreen(_this.el);
		};
		
		/* redéfini la fonction oNav.hideallbox pour prendre en compte le date picker dans l'événement de la touche ESCAPE */
		var fn = oNav.hideallbox;
		oNav.hideallbox = function(){
			fn();
			_this.hide();
		};
		
		/* ajoute la fonction de repositionnement du bouton close lié au srcolling de la page */
		oNav.addevent("onresize", _this.inscreen);
		oNav.addevent("onscroll", _this.inscreen);		
	}
	