	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* Le zoom sur image */
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oZoom = new Zoom();						/* Objet Zoom sur image */
	
	function Zoom(){									/* Zoom sur image */
	
		var _this = this;

		this.el = undefined;						/* objet image à zoomer */
		this.zoom = undefined;					/* objet zoom de l'image réduite */
		this.view = undefined;					/* objet conteneur de l'image normale */
		this.img = undefined;						/* objet image normale */
		this.file = "";									/* chemin complet du fichier image du viewer (optionnel) */
		this.position = "";							/* position droite (défaut) ou gauche du viewer */
		this.width = 0;									/* largeur de l'image du viewer obligatoire pour IE6 */
		this.height = 0;								/* hauteur de l'image du viewer obligatoire pour IE6 */
		this.size = 1;									/* taille du zoom par rapport à l'image 1 = identique à l'image; 2 = deux fois l'image... */ 
		
		this.show = function(event){				/* affiche le zoom d'un partie l'image destination */
		
			/* argument 0: event obligatoire*/
			/* argument 1: position right (défaut) or left [string] */
			/* argument 2: largeur image réélle obligatoire pour IE6 [integer] */
			/* argument 3: hauteur image réélle obligatoire pour IE6 [integer] */
			
			if( arguments.length <= 0 ){ return false; }
			
			/* élément à zoomer */
			var el = oEl.getevent(event);
			if( _this.el != undefined && el != _this.el ){ _this.hide(); }			
			
			/* si image vide */
			if( el.src.indexOf("vide.gif") != -1 ){
				return false;	
			}
			
			_this.el = el;
			
			/* arguments position ou chemin du fichier image du viewer */
			for( var i = 0; i < arguments.length; i++){
				if( typeof(arguments[i]) == "string" ){
					if( arguments[i] == "left" ){ _this.position = "left"; }
					else{ _this.file = arguments[i]; }
				}
			}
			
			/* récupère les dimensions de l'image réélle selon le nombre d'arguments passés */
			for( var i = 0; i < arguments.length; i++){
				if( (i < arguments.length -1) && !isNaN(arguments[i]) && !isNaN(arguments[i+1]) ){
					_this.width = parseFloat(arguments[i]);		
					_this.height = parseFloat(arguments[i+1]); 
				}
			}

			/* marges réelles suivant le navigateur */
			_this.margleft = oEl.getoffset(_this.el, "offsetLeft");
			_this.margtop = oEl.getoffset(_this.el, "offsetTop");
			_this.margleft = (oNav.msie) ? parseFloat(oNav.marginLeft) + _this.margleft : _this.margleft;
			_this.margtop =  (oNav.msie) ? parseFloat(oNav.marginTop) + _this.margtop : _this.margtop;
			
			/* Création du zoom et du view */
			if( _this.zoom == undefined ){
				_this.zoom = oEl.create("div");
				_this.zoom.className = "jaria_zoom_zoom";
				_this.zoom.style.width = (parseInt(parseFloat(_this.el.style.width) / 3)).toString() + "px";
				_this.zoom.style.height = (parseInt(parseFloat(_this.el.style.height) / 3)).toString() + "px";
				_this.el.parentNode.appendChild(_this.zoom);			
				oEl.opacity(_this.zoom, 50);
				_this.el.onmousemove = _this.drag;
				_this.zoom.onmousemove = _this.drag;
				_this.zoom.onmouseout = _this.hide;
				_this.view = oEl.create("div");
				_this.view.className = "jaria_zoom_view";
				_this.view.style.width = (parseInt(parseFloat(_this.el.style.width)) * _this.size).toString() + "px";
				_this.view.style.height = (parseInt(parseFloat(_this.el.style.height)) * _this.size).toString() + "px";
				_this.view.style.left = ( parseInt(_this.margleft + parseFloat(_this.el.style.width) + 15) ).toString() + "px";
				_this.view.style.top = (_this.margtop).toString() + "px";
				if( _this.position == "left" ){ _this.view.style.left = (_this.margleft - parseFloat(_this.view.style.width) - 15).toString() + "px"; }
				_this.el.parentNode.appendChild(_this.view);
				_this.img = oEl.create("img");
				_this.img.className = "jaria_zoom_img";				
				if( _this.width > 0 ){ _this.img.style.width = (_this.width).toString() + "px"; }
				if( _this.height > 0 ){ _this.img.style.height = (_this.height).toString() + "px"; }
				_this.img.style.left = (oNav.msie) ? (oEl.getoffset(_this.view, "offsetLeft")).toString() + "px" : (_this.view.offsetLeft).toString() + "px";
				_this.img.style.top = (oNav.msie) ? (oEl.getoffset(_this.view, "offsetTop")).toString() + "px" : (_this.view.offsetTop).toString() + "px";
				_this.img.src = ( _this.file == "" ) ? _this.el.src : _this.file;
				_this.view.appendChild(_this.img);
				_this.img.style.width = (_this.img.offsetWidth).toString() + "px";
				_this.img.style.height = (_this.img.offsetHeight).toString() + "px";
				_this.coefWidth = _this.img.offsetWidth / parseFloat(_this.el.style.width);
				_this.coefHeigth = _this.img.offsetHeight / parseFloat(_this.el.style.height);
				/* arrondi à l'entier supérieur */
				var w = (_this.coefWidth - parseInt(_this.coefWidth));
				var h = (_this.coefHeigth - parseInt(_this.coefHeigth));
				_this.coefWidth = ( w > 0 ) ? _this.coefWidth + (1 + (w / 2)) : _this.coefWidth + 1;
				_this.coefHeigth = ( h > 0 ) ? _this.coefHeigth + (1 + (h / 2)) : _this.coefHeigth + 1;
			}
		};
		
		this.drag = function(){						/* démarrage du déplacement de la loupe */
		
			try{
				var w = parseInt(parseFloat(_this.zoom.style.width) / 2);									/* demi-largeur du zoom */
				var h = parseInt( parseFloat(_this.zoom.style.height) / 2);									/* demi-hauteur du zoom */
				_this.zoom.style.left = ( oNav.mouse.X - w + oNav.scrollX ).toString() + "px";				/* souris au centre horizontal du zoom */
				_this.zoom.style.top = ( oNav.mouse.Y - h + oNav.scrollY ).toString() + "px";				/* souris au centre vertical du zoom */
				if( !oEl.isvisible(_this.zoom) ){
					oEl.visible(_this.zoom, true);
				}
				if( parseFloat(_this.zoom.style.left) < _this.margleft -2  ){ _this.zoom.style.left = (_this.margleft - 2).toString() + "px"; }
				if( parseFloat(_this.zoom.style.top) < _this.margtop - 2 ){ _this.zoom.style.top = (_this.margtop - 2).toString() + "px"; }
				if( parseFloat(_this.zoom.style.left) + parseFloat(_this.zoom.style.width) + 2 > _this.margleft + parseFloat(_this.el.style.width) + 2 ){ _this.zoom.style.left = ( parseFloat(_this.el.style.width) - parseFloat(_this.zoom.style.width) + _this.margleft ).toString() + "px"; }
				if( parseFloat(_this.zoom.style.top) + parseFloat(_this.zoom.style.height) + 2 > _this.margtop + parseFloat(_this.el.style.height) + 2 ){ _this.zoom.style.top = ( parseFloat(_this.el.style.height) - parseFloat(_this.zoom.style.height) + _this.margtop ).toString() + "px"; }
				
				/* position réélle en déplacement du coin haut gauche du zoom  */
				var l = parseFloat(_this.zoom.style.left) - _this.margleft + 1;
				var t = parseFloat(_this.zoom.style.top) - _this.margtop + 1;
				
				/* déplacement de l'image du zoom */
				_this.img.style.left = (  parseInt( (-l * _this.coefWidth) )  ).toString() + "px";
				_this.img.style.top = (  parseInt( (-t * _this.coefHeigth) )  ).toString() + "px";
				
			}catch(e){}
			
		};
		
		this.hide = function(){						/* détruit le zoom et le viewer */
			try{
				_this.el.parentNode.removeChild(_this.view);
				_this.el.parentNode.removeChild(_this.zoom);				
			}
			catch(e){}
			_this.el = undefined;
			_this.zoom = undefined;
			_this.img = undefined;
			_this.file = "";
			_this.width = 0;
			_this.height = 0;
			_this.position = "";
		};		
	}