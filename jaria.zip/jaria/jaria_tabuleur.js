	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* Le tabuleur & onglets */

	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oTab = new Tab();							/* Objet tabuleur à onglets */
	
	function Tab(){										/* tabuleur d'accès au pages par onglets */
	
		var _this = this;
	
		_this.el = undefined;						/* objet tabuleur */
		_this.tabs = [];								/* tableau à 2 dimensions contenant  l'objet, le texte et l'url de l'onglets ajouté */
		_this.parent = undefined;				/* élément parent du tabuleur */		
		_this.height = "";
		
		_this.add = function(){					/* ajout d'un onglet au tabuleur */
			/*
				argument 0 obligatoire :		texte de l'onglet à ajouter
				argument 1 obligatoire :		lien (url) de l'onglet à ajouter
			*/
			if( arguments.length < 2 ){
				return false;
			}
			if( !oEl.isobject(_this.el) ){
				_this.show();
			}		
			var text = oText.trim(arguments[0]);
			var url = oText.trim(arguments[1]);
			var nbtabs = _this.tabs.length;
			for( var i = 0; i < nbtabs; i++){				
				if( _this.tabs[i][1] == text || _this.tabs[i][2] == url ){	/* évite le doublon d'onglet */
					return false;
				}
			}
			var div = oEl.create("div");
			var onglet = oEl.create("div");
			onglet.className = "jaria_tabonglet";
			onglet.onclick = function(){
				_this.el.frm.src = url;
				var tabs = oEl.gettags("div", _this.el.tabs);
				for( var i = 0; i < tabs.length; i++){
					if( tabs[i].className == "jaria_tabongletsel" ){
						tabs[i].className = "jaria_tabonglet";
					}
				}
				_this.tabs[nbtabs][0].className = "jaria_tabongletsel";
			};
			onglet.onmouseover = function(){
				if( this.className != "jaria_tabongletsel" ){
					this.className = "jaria_tabongletover";
				}
			};
			onglet.onmouseout = function(){
				if( this.className != "jaria_tabongletsel" ){
					this.className = "jaria_tabonglet";
				}
			};
			var l = oEl.create("div");
			l.className = "jaria_tableft";
			onglet.appendChild(l);
			var c = oEl.create("div");
			c.className = "jaria_tabcenter";
			c.title = url;
			c.appendChild(oEl.text(text));
			onglet.appendChild(c);	
			var r = oEl.create("div");
			r.className = "jaria_tabright";
			onglet.appendChild(r);			
			div.appendChild(onglet);	
			_this.el.tabs.appendChild(div);
			_this.tabs[nbtabs] = new Array();
			_this.tabs[nbtabs][0] = onglet;
			_this.tabs[nbtabs][1] = text;
			_this.tabs[nbtabs][2] = url;
		};
		
		_this.del = function(){					/* supprime un onglet par le lien (url) */
			/*
				argument 0 obligatoire :		texte ou lien (url) de l'onglet à supprimer
			*/
			
			function tabdel(tab, lig){
				var newtab = new Array();
				y = 0;
				for( var i = 0; i < tab.length; i++ ){
					if( i != lig){
						newtab[y] = new Array();
						newtab[y][0] = tab[i][0];
						newtab[y][1] = tab[i][1];
						newtab[y][2] = tab[i][2];
						y++;
					}					
				}
				return newtab;
			}
			
			if( arguments.length < 1 ){
				return false;
			}	
			var arg = oText.trim(arguments[0]);
			/* Recherche par le texte par le ou lien (url) l'onglet à supprimer*/
			for( var i = 0; i < _this.tabs.length; i++){							
				if( _this.tabs[i][1] == arg || _this.tabs[i][2] == arg ){
					_this.tabs[i][0].parentNode.removeChild(_this.tabs[i][0]);
					_this.tabs = tabdel(_this.tabs, i);
					break;
				}
			}
			if( _this.tabs.length == 0 ){
				_this.el.frm.src = "vide.html";
				return false;
			}
			_this.select(_this.tabs[0][1]);
			
		};
		
		_this.select = function(){				/* sélection un onglet par le lien (url) */
			/*
				argument 0 obligatoire :		texte ou lien (url) de l'onglet à sélectionner
			*/
			if( arguments.length < 1 ){
				return false;
			}			
			var arg = oText.trim(arguments[0]);
			/* Recherche par le texte ou par le lien (url) l'onglet à sélectionner*/
			for( var i = 0; i < _this.tabs.length; i++){	
				_this.tabs[i][0].className = "jaria_tabonglet";
				if(_this.tabs[i][1] == arg || _this.tabs[i][2] == arg ){
					_this.tabs[i][0].className = "jaria_tabongletsel";
					_this.el.frm.src = _this.tabs[i][2];
				}
			}
		};
		
		_this.show = function(){					/* créé le tabuleur */
			/*
				argument 0 facultatif : élément parent 
			*/
			_this.hide();
			_this.parent = (_this.parent == undefined ) ? oNav.body : _this.parent;
			if( arguments.length > 0 ){
				if( oEl.isobject(arguments[0]) ){
					_this.parent = arguments[0];
				}else if( oEl.isobject(oEl.get(arguments[0])) ){
					_this.parent = oEl.get(arguments[0]);
				}
			}
			_this.el = oEl.create("div");
			_this.el.className = "jaria_tab";			
			_this.el.tabs = oEl.create("div");
			_this.el.cont = oEl.create("div");
			_this.el.frm = oEl.create("iframe");
			_this.el.frm.name = "tabfrm";
			_this.el.cont.className = "jaria_tabcont";
			_this.el.frm.className = "jaria_tabframe";
			_this.el.frm.frameBorder = "0";
			_this.el.frm.height = ( _this.height != "" ) ? parseFloat(_this.height) : 300;
			_this.el.appendChild(_this.el.tabs);
			_this.el.cont.appendChild(_this.el.frm);
			_this.el.appendChild(_this.el.cont);
			_this.parent.appendChild(_this.el);
			_this.tabs = new Array();			
		};
		
		_this.hide = function(){					/* détruit le tabuleur */
			try{
				_this.parent.removeChild(_this.el);
			}
			catch(e){}
			_this.el = undefined;
			_this.tabs = new Array();
		};
		
		_this.load = function(){
			oNav.loadimg(
				jaria.images + "tab/tabcenter.gif",
				jaria.images + "tab/tableft.gif",
				jaria.images + "tab/tabright.gif"
			);			
		};
		
	}
	
	oNav.addevent("onload", function(){
		oTab.load();
	});