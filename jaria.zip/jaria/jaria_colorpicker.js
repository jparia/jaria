	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
	
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	/* Le panel de couleurs */	

	oColor.picker = new Picker();
	
	function Picker(){
		
		var _this = this;
		var _color = new Color();
		
		this.input = [];
		this.btcolor = [];
		this.el = undefined;
		
		this.drag = function(event){						/* démarrage du déplacement du panel de couleur */
			oEl.drag.opacity = 65;
			oEl.drag.start(_this.el, event);
		};		
		
		this.hide = function(){								/* cache le panel de couleur [hide]*/
			var cp = _this;
			if( cp.el == undefined ){
				return false;
			}
			oNav.delevent("onresize", _this.inscreen);
			oNav.delevent("onscroll", _this.inscreen);
			try{
				oNav.body.removeChild(cp.el);
				if( !oBox.exist ) {
					oNav.lock.hide();
				}
			}catch(e){}
			cp.el = undefined;
			cp.valid = function(){};
			oText.select(true);
			oNav.contextmenu(true);
	
		};
		
		this.set = function(){								/* affecte une couleur à l'objet color */
			/*
			argument 1: identifiant de l'élément couleur
			argument 1: couleur à affecter
			*/
			if( arguments.length ==0 ){
				return false;	
			}
			if( !oEl.test(arguments[0]) ){
				return false;				
			}
			if( !_color.iscolor(arguments[1]) ){
				return false;				
			}
			var parent = oEl.get(arguments[0]).parentNode;
			oEl.get(arguments[0]).value = arguments[1];
			for( var i = 0; i < parent.childNodes.length; i++ ){
				if( parent.childNodes[i].nodeType == 1 ){
					if( oText.lower(parent.childNodes[i].tagName) == "div" ){
						var div = parent.childNodes[i];
						for( var y = 0; y < div.childNodes.length; y++ ){
							if( div.childNodes[y].nodeType == 1 ){								
								if( oText.lower(div.childNodes[y].className) == "jaria_btscolor" ){
									div.childNodes[y].style.backgroundColor = arguments[1];
									break;
								}
							}
						}
					}
				}
			}
		};
		
		this.getindex = function(){			/* retourne l'index du tableau des éléments pour l'élément passé en paramètre */
			/*
				argument 0 : obligatoire		un des éléments que compose l'objet Color
			*/
			var el = arguments[0];
			if( !oEl.isobject(el) ){
				return 0;			  
			}
			
			if( el.tagName.toLowerCase() != "input" ){		/* un autre élément de l'objet Color */
				var parent = el.parentNode;
				el = oEl.gettags("input", parent)[0];
			}
			for( var i = 0; i < this.input.length; i++ ){
				if( el == this.input[i] ){
					break;
				}
			}
			if( !oEl.isobject(this.input[i]) ){
				this.input.push(el);
				return this.input.length -1;
			}
			return i;
		};
		
		this.show = function(el){			/* créé et affiche le panel */
			/*
				argument 0 : obligatoire		un des éléments que compose l'objet Color
			*/
			if( !oEl.isobject(el) || !oNav.ready ){
				return false;	
			}
			if(_this.el != undefined){
				this.hide();
			}
			oNav.lock.anim = false;
			oNav.lock.show();
			oText.select(false);
			oNav.contextmenu(false);
			var tab = new Array();
			var parent, div, sdiv, img, tb, tbo, tr, td;
			tab[0] =	new Array("#000", "#000", "#030", "#060", "#090", "#0c0", "#0f0", "#300", "#330", "#360", "#390", "#3c0", "#3f0", "#600", "#630", "#660", "#690", "#6c0", "#6f0");
			tab[1] =	new Array("#333", "#003", "#033", "#063", "#093", "#0c3", "#0f3", "#303", "#333", "#363", "#393", "#3c3", "#3f3", "#603", "#633", "#663", "#693", "#6c3", "#6f3");
			tab[2] =	new Array("#666", "#006", "#036", "#066", "#096", "#0c6", "#0f6", "#306", "#336", "#366", "#396", "#3c6", "#3f6", "#606", "#636", "#666", "#696", "#6c6", "#6f6");
			tab[3] =	new Array("#999", "#009", "#039", "#069", "#099", "#0c9", "#0f9", "#309", "#339", "#369", "#399", "#3c9", "#3f9", "#609", "#639", "#669", "#699", "#6c9", "#6f9");
			tab[4] =	new Array("#ccc", "#00c", "#03c", "#06c", "#09c", "#0cc", "#0fc", "#30c", "#33c", "#36c", "#39c", "#3cc", "#3fc", "#60c", "#63c", "#66c", "#69c", "#6cc", "#6fc");
			tab[5] =	new Array("#fff", "#00f", "#03f", "#06f", "#09f", "#0cf", "#0ff", "#30f", "#33f", "#36f", "#39f", "#3cf", "#3ff", "#60f", "#63f", "#66f", "#69f", "#6cf", "#6ff");
			tab[6] =	new Array("#f00", "#900", "#930", "#960", "#990", "#9c0", "#9f0", "#c00", "#c30", "#c60", "#c90", "#cc0", "#cf0", "#f00", "#f30", "#f60", "#f90", "#fc0", "#ff0");
			tab[7] =	new Array("#0f0", "#903", "#933", "#963", "#993", "#9c3", "#9f3", "#c03", "#c33", "#c63", "#c93", "#cc3", "#cf3", "#f03", "#f33", "#f63", "#f93", "#fc3", "#ff3");
			tab[8] =	new Array("#00f", "#906", "#936", "#966", "#996", "#9c6", "#9f6", "#c06", "#c36", "#c66", "#c96", "#cc6", "#cf6", "#f06", "#f36", "#f66", "#f96", "#fc6", "#ff6");
			tab[9] =	new Array("#ff0", "#909", "#939", "#969", "#999", "#9c9", "#9f9", "#c09", "#c39", "#c69", "#c99", "#cc9", "#cf9", "#f09", "#f39", "#f69", "#f99", "#fc9", "#ff9");
			tab[10] =	new Array("#0ff", "#90c", "#93c", "#96c", "#99c", "#9cc", "#9fc", "#c0c", "#c3c", "#c6c", "#c9c", "#ccc", "#cfc", "#f0c", "#f3c", "#f6c", "#f9c", "#fcc", "#ffc");
			tab[11] =	new Array("#f0f", "#90f", "#93f", "#96f", "#99f", "#9cf", "#9ff", "#c0f", "#c3f", "#c6f", "#c9f", "#ccf", "#cff", "#f0f", "#f3f", "#f6f", "#f9f", "#fcf", "#fff");
			
			var index = this.getindex(el);
			var parent = el.parentNode;			
			this.btcolor[index] = oEl.getclass("jaria_btscolor", parent, true)[0];		
			this.input[index].onkeyup = function(){		/* évènement clavier sur l'élément input*/
				if( this.value != "" && this.value.substr(0, 1) != "#"){
					this.value = "#" + this.value.substr(0, 7);
				}
				if( !_color.iscolor(this.value) ){
					_this.btcolor[index].style.backgroundColor = "";
				}else{
					_this.btcolor[index].style.backgroundColor = this.value;
				}
			};
			this.el = oEl.create("div");
			this.el.className = "jaria_colorbox";
			div = oEl.create("div");
			div.className = "jaria_colorhead";
			div.onmousedown = this.drag;
			div.title = "clic droit ou [esc] pour quitter";
			div.oncontextmenu = this.hide;
			this.el.appendChild(div);
			sdiv = oEl.create("div");
			sdiv.className = "jaria_colorplus";
			sdiv.title = "Afficher plus de couleurs";
			sdiv.onclick = function(){
				/*Couleurs avancées pas encore développé*/
			};
			div.appendChild(sdiv);
			tb = oEl.create("table");
			this.el.appendChild(tb);
			tbo = oEl.create("tbody");
			tb.appendChild(tbo);
			for( var i = 0; i < tab.length; i++ ){
				tr = oEl.create("tr");
				for( var y = 0; y < tab[i].length; y++ ){
					td = oEl.create("td");
					sdiv = oEl.create("div");
					sdiv.className = "jaria_colorcase";
					sdiv.style.backgroundColor = tab[i][y];
					sdiv.innerHTML = "&nbsp;";
					sdiv.onmouseout = function(){
						this.parentNode.style.border = "1px solid #F9F8F7";
					};
					sdiv.onmouseover = function(){
						var cp = _this;
						cp.el.lastChild.firstChild.style.backgroundColor = this.style.backgroundColor;
						cp.el.lastChild.lastChild.innerHTML = _color.navcolor(this.style.backgroundColor);
						this.parentNode.style.border = "1px solid #069";
					};
					sdiv.onclick = function(){
						var cp = _this;
						cp.btcolor[index].style.backgroundColor = _color.navcolor(oText.upper(this.style.backgroundColor));
						cp.input[index].value = _color.navcolor(oText.upper(this.style.backgroundColor));
						cp.valid();
						cp.hide();
					};
					td.appendChild(sdiv);
					td.style.border = "1px solid #F9F8F7";
					tr.appendChild(td);
				}
				tbo.appendChild(tr);
			}
			div = oEl.create("div");
			div.className = "jaria_colortext";
			div.style.paddingLeft="3px";			
			sdiv = oEl.create("div");
			sdiv.innerHTML = "&nbsp;";
			sdiv.style.width = "14px";
			sdiv.style.styleFloat = "left";
			div.appendChild(sdiv);			
			sdiv = oEl.create("div");
			sdiv.innerHTML = "&nbsp;";
			div.appendChild(sdiv);
			this.el.appendChild(div);
			this.el.style.left = oText.toPx(oNav.mouse.X + oNav.scrollX);
			this.el.style.top = oText.toPx(oNav.mouse.Y + oNav.scrollY);
			oNav.body.appendChild(_this.el);
			oEl.setinscreen(this.el);
		};

		this.valid = function(){	/* fonction pouvant être redéfinie pour un action après le choix de la couleur */
			return false;
		};
		
		this.load = function(){
			oNav.loadimg(
				jaria.images + "color/color.gif",
				jaria.images + "color/colorplus.gif"
			);			
		};
		
		this.inscreen = function(){
			if ( oEl.isobject(_this.el) ){
				oEl.setinscreen(_this.el);
			}
		};
		
		/* red�fini la fonction oNav.hideallbox pour prendre en compte le picker color dans l'�v�nement de la touche ESCAPE */
		oNav.hideallbox = function(){
			oNav.hideallbox;
			_this.hide();
		};
		
		/* ajoute la fonction de repositionnement du bouton close li� au srcolling de la page */
		oNav.addevent("onresize", _this.inscreen);
		oNav.addevent("onscroll", _this.inscreen);	
		
	}
	
	oNav.addevent("onload", function(){
		oColor.picker.load();
	});
	
	
