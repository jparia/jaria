	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources d�veloppeur
	*/
		
	/* L'animation du background */
	
	/* v�rifie l'existence de la biblioth�que */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oAnim = new Anim();
	
	function Anim(){
		this.path = "images/";			/* chemin des images du background */
		this.image = [];				/* tableau des images du background pour le pr�chargement */
		this.color = [];				/* tableau des couleur de fond du background */
		this.num = 0;					/* N� d'image du background en cours */
		this.timer = null;				/* identifiant du timer */
		this.delai = 5000;				/* d�lai d'animation en ms */
		this.el = null;					/* �lement recevant le background */ 
		this.loaded = false;			/* images de fond charg�es */
		this.loading = false;			/* afficher la fen�tre de chargement */
		this.wait = undefined;			/* objet fen�tre de chargement */
		
		this.loadImage = function(){			/* pr�chargement de l'image en cours */
			if( arguments.length < 2 ){
				return false;
			}
			if( isNaN(arguments[0]) || !oText.test(arguments[1]) ){
				return false;
			}
			var i = parseInt(arguments[0]);
			this.image[i] = new Image;
			this.image[i].src = this.path + oText.trim(arguments[1]);
		};
		
		this.images = function(){				/* initie le tableau des images de fond selon les param�tres pass�es (1 chaine dont les valeurs sont s�par�es par une virgule ou plusieurs chaines) */
			if( arguments.length == 0 ){
				this.image = [];
				return false;
			}
			var imgs = oText.trim(arguments[0].toString());
			if( arguments.length == 1 ){				
				if( imgs.indexOf(",") == -1 ){
					this.loadImage(0, imgs);
				}else{				
					imgs = imgs.split(",");
					for( var i = 0; i < imgs.length; i++){	
						this.loadImage(i, imgs[i]);
					}
				}				
			}else{
				for( var i = 0; i < arguments.length; i++){
					this.loadImage(i, arguments[i].toString());
				}
			}
		};
		
		this.colors = function(){				/* initie le tableau des couleur de fond selon les param�tres pass�es (1 chaine dont les valeurs sont s�par�es par une virgule ou plusieurs chaines) */
			if( arguments.length == 0 ){
				this.color = [];
				return false;
			}
			var txt = oText.trim(arguments[0].toString());
			if( arguments.length == 1 && txt != "" ){
				if( txt.indexOf(",") == -1 ){
					this.color[0] = txt;
				}else{					
					this.color = txt.split(",");
				}				
			}else{
				this.color = arguments;
			}			
		};
		
		this.delWait = function(){
			oNav.lock.hide();
			if( this.wait != undefined ){
				try{
					oNav.body.removeChild(this.wait);					
				}catch(E){}
			}
			this.wait = undefined;
		};
		
		this.createWait = function(){			/* cr�ation de la fen�tre de chargement */
			if( !this.loading ){
				return false;
			}
			this.delWait();
			oNav.lock.anim = false;
			oNav.lock.show();
			this.wait = oEl.create("div");
			this.wait.className = "jaria_anim_wait";
			var text = oEl.text("Patientez pendant le chargement des images...");
			this.wait.appendChild(text);
			oNav.body.appendChild(this.wait);
			this.wait.style.left = oText.toPx( (oNav.screenX / 2) - (oEl.getoffset(this.wait, "offsetWidth") / 2) + oNav.scrollX );
			this.wait.style.top = oText.toPx( (oNav.screenY / 2) - (oEl.getoffset(this.wait, "offsetHeight") / 2) + oNav.scrollY );
		};
		
		this.isLoaded = function(){	
			if( this.num >= this.image.length ){
				this.loaded = true;
				this.num = 0;
				return false;				
			}
			try{
				this.wait.removeChild(this.wait.childNodes[0]);			
				var t = "Patientez pendant le chargement de l'image " + (this.num + 1).toString() + "/" + this.image.length.toString() + " : " + oText.filefullname(this.image[this.num].src);
				var text = oEl.text(t);
				this.wait.appendChild(text);
				if( this.image[this.num].complete ){
					this.num ++;
				}
			}catch(e){}
		};
		
		this.set = function(){				/* affecte l'image en cours au fond d'�cran */	
			this.isLoaded();
			if( this.loaded ){
				if( this.num > this.image.length || this.image[this.num] == undefined ){				
					this.num = 0;
				}
				this.delWait();
				this.el.style.backgroundImage = "url(" + this.image[this.num].src + ")";
				this.el.style.backgroundColor =  oText.trim(this.color[this.num]);	
				this.num++;
				this.action();
				this.timer = window.setTimeout("oAnim.start()", this.delai);
			}else{
				this.timer = window.setTimeout("oAnim.set()", 100);
			}
			
		};
		
		this.start = function(){			/* d�marage de l'animation */			
			if( this.el == null ){
				this.el = oNav.body;
				this.createWait();
			}
			if( this.num > this.image.length || this.image[this.num] == undefined ){				
				this.num = 0;
			}
			oNav.init_timer(this.timer);
			this.set();		
		};
		
		this.action = function(){			/* action � red�finir lors du changment d'image */
			return false;
		};
		
		this.delImages = function(){
			for( var i = 0; i < this.image.length; i++ ){
				try{
					oNav.body.removeChild(this.image[i]);
				}catch(e){}
			}
		};
		
		this.clear = function(){
			this.delWait();
			this.delImages();
			oNav.init_timer(this.timer);
			this.path = "images/";
			this.image = [];
			this.color = [];
			this.num = 0;
			this.delai = 5000;
			this.el = null;
		};
	}
