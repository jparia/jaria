	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources développeur
	*/
		
	/* vérifie l'existence de la bibliothèque */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library 'Jaria' is not loaded!");
	}
	
	/* Le panel des heures */
	
	oCal.timepicker = new TimePicker();
			
	function TimePicker(){
		
		var _this = this;
		
		this.el = undefined;
		this.left = null;
		this.top = null;
		this.hour = "";
		this.minute = "";
		this.id = "";
		
		this.set = function(el, t){
			if( t == "h" ){
				this.hour = el.innerHTML;
				oEl.get(this.id).value = (this.minute != "") ? this.hour  + ":" + this.minute : this.hour  + ":00";
			}
			else{
				this.minute = el.innerHTML;
				oEl.get(this.id).value = (this.hour != "") ? this.hour  + ":" + this.minute : "00:" + this.minute;
			}
			if(this.hour != "" && this.minute != ""){
				this.valid();
				this.hide();
			}				
		};
		
		this.drag = function(event){
			oEl.drag.opacity = 65;
			oEl.drag.start(_this.el, event);
		};
		
		this.get = function(){
			var h = oText.trim(oEl.get(this.id).value);
			var m = "";
			if( h != "" ){
				var t = h.split(":");
				if( t.length > 0 ){
					h = t[0];
					m = t[1];
				}
				if( !isNaN(h) && parseFloat(h) >= 0 && parseFloat(h) <= 23 ){
					this.hour = ( parseInt(h) < 10 ) ? "0" + parseInt(h).toString() : parseInt(h).toString();
				}
				if( !isNaN(m) && parseFloat(m) >= 0 && parseFloat(m) <= 55 ){
					this.minute = ( parseInt(m) < 10 ) ? "0" + parseInt(m).toString() : parseInt(m).toString();
				}
			}
		};
		
		this.show = function(id){
			if(!oEl.test(id) || !oNav.ready){
				return false;	
			}
			oNav.hideallbox();
			oText.select(false);
			this.id = id;
			this.get();
			this.el = oEl.create("div");
			this.el.className = "jaria_cal_box";
			this.el.style.width = "155px";
			div = oEl.create("div");
			div.className = "jaria_cal_head";
			div.onmousedown = this.drag;
			div.title = "clic droit ou [esc] pour quitter";
			div.oncontextmenu = this.hide;
			this.el.appendChild(div);
			div = oEl.create("div");
			div.style.paddingTop = "2px";
			tb = oEl.create("table");
			tb.className = "jaria_cal_tb";
			tbo = oEl.create("tbody");
			tr = oEl.create("tr");
			td = oEl.create("td");
			td.colSpan = 6;
			td.className = "jaria_cal_tdday";
			td.innerHTML = "Heures";
			tr.appendChild(td);
			td = oEl.create("td");
			td.className = "jaria_cal_tdday";
			td.rowSpan = 5;
			td.innerHTML = "&nbsp;";
			tr.appendChild(td);
			td = oEl.create("td");
			td.colSpan = 3;
			td.className = "jaria_cal_tdday";
			td.innerHTML = "Minutes";
			tr.appendChild(td);
			tbo.appendChild(tr);
			var h = 0;
			var m = 0;
			for( var i = 0; i < 4; i++ ){
				tr = oEl.create("tr");					
				for( var y = 0; y < 6; y++ ){
					td = oEl.create("td");						
					td.innerHTML = ( h < 10 ) ? "0" + h.toString() :  h.toString();					
					td.onclick = function(){
						_this.set(this, "h");
					};
					td.className = "jaria_cal_tdnoday";
					td.onmouseover = function(){
						this.className = "jaria_cal_tdodayov";
					};
					td.onmouseout = function(){
						this.className = "jaria_cal_tdnoday";
					};
					tr.appendChild(td);
					h++;
				}
				for( var y = 0; y < 3; y++ ){
					td = oEl.create("td");						
					td.innerHTML = ( m < 10 ) ? "0" + m.toString() :  m.toString();						
					td.onclick = function(){
						_this.set(this, "m");
					};
					td.className = "jaria_cal_tdnoday";
					td.onmouseover = function(){
						this.className = "jaria_cal_tdodayov";
					};
					td.onmouseout = function(){
						this.className = "jaria_cal_tdnoday";
					};
					tr.appendChild(td);
					m = m + 5;
				}	
				tbo.appendChild(tr);
			}
			tb.appendChild(tbo);
			div.appendChild(tb);
		
			this.el.appendChild(div);
			oNav.body.appendChild(this.el);	
			oNav.contextmenu(false, this.el);
			this.el.style.left = (this.left == null) ? oText.toPx(oNav.mouse.X + oNav.scrollX) : oText.toPx(this.left);
			this.el.style.top = (this.top == null) ? oText.toPx(oNav.mouse.Y + oNav.scrollY) : oText.toPx(this.top);
			oEl.setinscreen(this.el);
		};
		
		this.hide = function(){
			if( _this.el == undefined ){
				return false;
			}
			try{
				oNav.body.removeChild(_this.el);
			}
			catch(e){};
			_this.el = undefined;
			_this.id = "";
			_this.left = null;
			_this.top = null;
			_this.hour = "";
			_this.minute = "";
			oText.select(true);
			oNav.contextmenu(true);
			this.valid = function(){};
		};
		
		this.valid = function(){
			/* Action supplémentaire à effectuer sur le choix d'une heure */	
		};
		
		this.inscreen = function(){
			 oEl.setinscreen(_this.el);
		};
		
		/* redéfini la fonction oNav.hideallbox pour prendre en compte le date picker dans l'événement de la touche ESCAPE */
		var fn = oNav.hideallbox;
		oNav.hideallbox = function(){
			fn();
			_this.hide();
		};
		
		/* ajoute la fonction de repositionnement du bouton close lié au srcolling de la page */
		oNav.addevent("onresize", _this.inscreen);
		oNav.addevent("onscroll", _this.inscreen);		
	}	