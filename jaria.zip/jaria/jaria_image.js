	/*	Librairie JS JARIA
		Copyright (c) 2008 Jean-Pierre ARIA (jaria.free.fr)
		sources d�veloppeur
	*/
	
	/* Gestion d'image */
	
	/* v�rifie l'existence de la biblioth�que */
	if( typeof(jaria) != "object" ){
		alert("The JavaScript library Jaria is not loaded!");
	}
	
	var oImg = [];					/* tableau d'instances de la fonction Img() */
	
	function Img(){	
		
		this.onLoad = false;		/* image en cours de chargement */
		this.isLoad = false;		/* image charg�e en m�moire */
		this.img = "";				/* �l�ment image */
		this.timer = null;			/* timer de v�rification du chargement */
		this.width = 0;				/* largeur de l'image charg�e */
		this.height = 0;			/* hauteur de l'image charg�e */
		this.num = 0;				/* num�ro de l'instance en cours */
		this.view = new View();		/* fonction pour visionner une image */			
		
		/* v�rifie le chargement en m�moire de l'image */
		this.get = function(){			
			try{
				if (this.img.complete){
        			this.isLoad = true;
    			}
			}catch(e){
				if (typeof this.img.naturalWidth != "undefined" && this.img.naturalWidth != 0){
					this.isLoad = true;
				}
			}				
			if (this.isLoad == true){
				this.finaly();
			}
		};
		
		/* charge l'image l'url est pass�e en param�tre */ 
		this.load = function(){
			/* 
				argument 0 : string	obligatoire		url de l'image � charger
			*/
			
			if( !oEl.istype(arguments[0], "string") ){
				return false;
			}
			this.init();
			this.img = new Image();
			this.img.src = arguments[0];
			this.onLoad = true;
			this.num = this.getindex(arguments[0]);			
			this.onload();
			this.timer = window.setInterval("oImg[" + this.num + "].get()", 500);

		};
		
		/* image charg�e en m�moire */
		this.finaly = function(){
			oNav.init_timer(this.timer);
			this.width = this.getwidth();
			this.height = this.getheight();
			this.onLoad = false;
			this.loaded();
		};
		
		/* fonction � red�finir pour l'affichage du temps d'attente de chargement */
		this.onload = function(){					
			return false;
		};
		
		/* fonction � red�finir pour l'affichage de l'image une fois charg�e */
		this.loaded = function(){
			return false;
		};
		
		/* r�tourne le n� d'instance selon l'url pass�e en param�tre */
		this.getindex = function(url){
			for( var i = 0; i < oImg.length; i++ ){
				if( oImg[i].img.src.indexOf(url) != -1 ){
					return i;
				}
			}
			return 0;
		};
		
		/* r�tourne l'instance selon l'url pass�e en param�tre */
		this.getinstance = function(url){
			for( var i = 0; i < oImg.length; i++ ){
				if( oImg[i].img.src.indexOf(url) != -1 ){
					return oImg[i];
				}
			}
			return null;
		};
		
		/* retourne l'objet la visionneuse active */
		this.getview = function(){
			for( var  i = 0; i < oImg.length; i++ ){
				if( oImg[i].view.el != undefined ){
					return oImg[i].view;
				}
			}
			return undefined;
		};
				
		/* retourne la largeur r�elle de l'image */
		this.getwidth = function(){
			if( this.isLoad ){
				if(typeof(this.img.naturalWidth) != "undefined"){
					return this.img.naturalWidth;
				}
				var img = new Image();
				img.src = this.img.src;
				return img.width;
			}
		};
		
		/* retourne la largeur r�elle de l'image */
		this.getheight = function(){
			if( this.isLoad ){
				if(typeof(this.img.naturalHeight) != "undefined") {
					return this.img.naturalHeight;
				}
				var img = new Image();
				img.src = this.img.src;
				return img.height;
			}
		};
		
		/* raz de l'image pr�c�demment charg�e */
		this.init = function(){
			this.isLoad = false;
			this.img = "";
			this.width = 0;
			this.height = 0;
			oNav.init_timer(this.timer);
			this.timer = null;
		};
		
		/* visionneuse d'image */
		function View(){
		
			this.img = undefined;						/* objet image source � visionner */
			this.el = undefined;						/* objet conteneur de la visionneuse */
			this.vimg = undefined;						/* objet image de la visionneuse */
			this.bt = undefined;						/* objet bouton de fermeture (close) */
			this.width = 0;								/* largeur de l'image reelle */
			this.height = 0;							/* hauteur de l'image reelle */
			this.timer = null;							/* timer de la visionneuse */
			this.padding = 0;							/* padding attribu� � la visionneuse par style CSS */
			this.isfinaly = false;						/* visionneuse finalis�e */
			
			this.posclose = function(){					/* position du bouton de fermeture en haut � droite de la visionneuse */
				if ( oEl.isobject(this.bt) && oEl.isobject(this.el) ){
					this.bt.style.left = oText.toPx( parseInt(parseFloat(this.el.style.left) + parseFloat(this.el.style.width) - (this.padding / 2)) );
					this.bt.style.top = oText.toPx( parseInt(parseFloat(this.el.style.top) + this.padding) );
				}
			};
			
			this.inscreen = function(){
				oEl.isinscreen = function(){			/* en fin de repositionnement de la visionneuse dans la fen�tre du navigateur */
					var obj = oImg[0].getview();
					if( !oEl.isobject(obj) ){
						return false;
					}
					if( !oEl.isobject(obj.bt) ){		/* on cr� le bouton de fermeture de la visionneuse */				
						obj.bt = oEl.create("img");
						obj.bt.className = "jaria_viewer_close";
						obj.bt.src = jaria.images + "close.gif";
						obj.bt.alt = "";
						obj.bt.title = "Fermer la visionneuse [esc]";			
						obj.bt.onmouseover = function(){
							this.src = jaria.images + "close_over.gif";
						};
						obj.bt.onmouseout = function(){
							this.src = jaria.images + "close.gif";
						};
						obj.bt.onclick = oNav.hideallbox;
						oNav.body.appendChild(obj.bt);	
						var f = (oNav.msie) ? 10 : 40;
						oEl.fader.plus(obj.bt, f);										
					}
					obj.posclose();
				};
				oEl.setinscreen(this.el);				/* repositionne la visionneuse dans la fen�tre du navigateur */
			};
			
			this.finaly = function(){					/* Actions finales apr�s agrandissement termin� de la visionneuse */			
				if( oEl.isobject(this.bt) ){
					return false;
				}
				this.isfinaly = true;			
				this.inscreen();						/* appelle la fonction de repositionnement d'�l�ment dans la fen�tre du navigateur */		
			};
			
			this.enlarge = function(){
				if( this.img == undefined ){				
					return false;
				}
				if( !this.isfinaly ){
				
					var inc = 40;
					var rapp = ( this.width > this.height ) ? parseFloat(this.height) / parseFloat(this.width) : parseFloat(this.width) / parseFloat(this.height) ;
					var incW = ( this.width > this.height ) ? parseFloat(inc) / parseFloat(rapp) : parseFloat(inc);
					var incH = ( this.height > this.width ) ? parseFloat(inc) / parseFloat(rapp) : parseFloat(inc);
					
					/* dimension r�elle atteinte */
					if( parseFloat(this.el.style.width) >= this.width && parseFloat(this.el.style.height) >= this.height ){
						oNav.init_timer(this.timer);
						this.timer = null;				
						this.finaly();
					}
					/* agrandie l'image jusqu'aux dimensions pass�es en param�tre */
					if( parseFloat(this.vimg.style.width) < this.width ){
						this.el.style.width = oText.toPx(parseInt(parseFloat(this.el.style.width) + incW));
						this.vimg.style.width = oText.toPx(parseInt(parseFloat(this.vimg.style.width) + incW));
					}
					if( parseFloat(this.vimg.style.height) < this.height ){
						this.el.style.height = oText.toPx(parseInt(parseFloat(this.el.style.height) + incH));
						this.vimg.style.height = oText.toPx(parseInt(parseFloat(this.vimg.style.height) + incH));
					}
					/* centre l'image sur sa r�f�rence */
					if( parseFloat(this.el.style.left) > oNav.scrollX ){
						this.el.style.left = oText.toPx( parseInt(oEl.getoffset(this.img, "offsetLeft") + (oEl.getoffset(this.img, "offsetWidth") / 2) - (parseFloat(this.el.style.width) / 2)) );
					}
					if( parseFloat(this.el.style.top) > oNav.scrollY ){
						this.el.style.top = oText.toPx( parseInt(oEl.getoffset(this.img, "offsetTop") + (oEl.getoffset(this.img, "offsetHeight") / 2) - (parseFloat(this.el.style.height) / 2)) );
					}
					var num = oImg[0].getindex(this.img.src);					
					this.timer = window.setTimeout("oImg[" + num  + "].view.enlarge()", 10);
				}
			};
			
			this.show = function(event){				/* affiche la visionneuse */
			
				/* 
					argument 0: event obligatoire
					argument 1: number facultatif		largeur de l'image � visionner	
					argument 2: number facultatif		hauteur de l'image � visionner	
				
				*/
				
				if( oNav.body == null ){
					return false;
				}
				
				if( arguments.length <= 0 ){
					return false;
				}
				
				/* �l�ment � zoomer */
				var el = ( !oNav.msie ) ? event.target : window.event.srcElement;				
				
				if (el.tagName.toLowerCase() != "img"){
					return false;
				}
				
				this.img = el;
				
				/* ajoute la fonction de repositionnement aux �v�nements scroll et resize */
				oNav.addevent("onresize", this.posclose);
				oNav.addevent("onscroll", this.inscreen);
				
				/*r�cup�re l'index du tableau de l'instance en cours */
				var obj = oImg[0].getinstance(this.img.src);
				
				/* red�fini la fonction oNav.hideallbox pour prendre en compte la visionneuse d'image dans l'�v�nement de la touche ESCAPE */
				oNewNav = new Nav();
				oNav.hideallbox = function(){
					oNewNav.hideallbox();
					obj.view.hide();
				};
				
				/* Cr�ation du viewer  */
				if( !oEl.isobject(this.el) ){
					oNav.lock.opacity = 80;
					oNav.lock.show();
					/* conteneur principale du viewer */
					this.el = oEl.create("div");
					this.el.className = "jaria_viewer";
					var prop = "offsetWidth";
					this.el.style.width = oText.toPx(oEl.getoffset(this.img, "offsetWidth"));
					this.el.style.height = oText.toPx(oEl.getoffset(this.img, "offsetHeight"));
					this.el.style.top = oText.toPx(oEl.getoffset(this.img, "offsetTop") - 20);
					this.el.style.left = oText.toPx(oEl.getoffset(this.img, "offsetLeft") - 20);				
					/* image de viewer */
					this.vimg = oEl.create("img");
					this.vimg.className = "jaria_viewer_img";
					this.vimg.src = el.src;
					this.vimg.onclick = oNav.hideallbox;
					this.vimg.title = "Fermer la visionneuse";
					this.vimg.style.width = oText.toPx(oEl.getoffset(this.img, "offsetWidth"));
					this.vimg.style.height = oText.toPx(oEl.getoffset(this.img, "offsetHeight"));
					/* ajout du viewer dans le DOM */
					this.el.appendChild(this.vimg);
					oNav.body.appendChild(this.el);
					/* marge d�finie dans le CSS */
					this.padding = parseFloat(oEl.getstyleclass(this.el, "paddingLeft"));
					/* dimensions r�elles de l'image */
					this.width = obj.getwidth();
					this.height = obj.getheight();
					if( arguments.length >= 3 ){
						if( !isNaN(arguments[1]) && !isNaN(arguments[2]) ){
							this.width = parseInt(arguments[1]);
							this.height = parseInt(arguments[2]);
						}				
					}
					var f = (oNav.msie) ? 10 : 40;
					oEl.fader.plus(this.el, f);
					this.isfinaly = false;
					this.enlarge();
				}
				
				/* red�fini l'�v�nement onresize pour prendre en compte le repositionnement de la visioneuse dans la fen�tre par la fonction oEl.setinscreen() */
				oNav.addevent("onresize",  function(){
						try{
							var obj = oImg[0].getview();
							if( oEl.isobject(obj) ){
								obj.inscreen();
							}
						}
						catch(e){}
					}
				);
				
				
				/* red�fini l'�v�nement onscroll pour prendre en compte le repositionnement de la visioneuse dans la fen�tre par la fonction oEl.setinscreen() */
				oNav.addevent("onscroll", function(){
						try{
							var obj = oImg[0].getview();
							if( oEl.isobject(obj) ){
								obj.inscreen();
							}	
						}
						catch(e){}
					}
				);
				
			};
			
			this.hide = function(){						/* d�truit la visionneuse */			
				try{
					oNav.body.removeChild(this.bt);
				}
				catch(e){}
				/* red�fini la fonction de fin du fader */
				oEl.fader.valid = function(){
					this.valid = function(){
						return false;
					};
					if ( arguments.length < 1 ){
						return false;	
					}
					var obj = null;
					try{
						var obj = oImg[0].getview();
						if( !oEl.isobject(obj) ){
							return false;
						}
						oNav.init_timer(obj.timer);
						try{
							oNav.body.removeChild(obj.bt);
						}
						catch(e){}
						try{
							oNav.body.removeChild(obj.el);					
						}
						catch(e){}
						oNav.lock.hide();
						obj.img = undefined;
						obj.el = undefined;
						obj.vimg = undefined;
						obj.bt = undefined;
						obj.width = 0;
						obj.height = 0;
						obj.timer = null;
						obj.isfinaly = false;
					}
					catch(e){
						return false;
					}
					
				};
				var f = (oNav.msie) ? 10 : 40;
				oEl.fader.moins(this.el, f);
			};			
		}

	}